# Supplemental material for the English revision

The root README.txt explains the archived workflow experiments. The followup
directory contains the matched rewrite protocol, outputs, scripts, model
run metadata, and figure rendering code. The figures directory includes
full-width vector PDF and 400-DPI PNG versions.

The original archive scores can be verified from cached outputs. The hosted
models used for generation are documented in recorded_model_execution.md.
New hosted generations can vary from the frozen records.

From the extracted supplement, stage a fresh workspace and enter it:

    python followup/prepare_workspace.py <empty-directory>
    cd <empty-directory>

Recompute the matched rewrite replay from recorded outputs with Python
3.12, NumPy, and scikit-learn:

    python work/ieee_manuscript_followup/paraphrase/replay_rewrites.py

Render both figures from the unchanged source CSVs and archived replay:

    python work/ieee_revision/ieee_figures.py

The local classifier outputs, protocols, and model identifiers are under
followup/paraphrase. The archived classifications can be rescored offline
without the model weights. To regenerate them, fetch the checkpoint with
the reported revision and verify its hashes against the protocol. The
local classifiers read only the synthetic evidence texts.

For the PyTorch classifier, pass the path to the recorded complete model
snapshot. See judge-protocol.json for dependency versions and frozen inputs.

    python work/ieee_manuscript_followup/paraphrase/judge.py --model <checkpoint>
