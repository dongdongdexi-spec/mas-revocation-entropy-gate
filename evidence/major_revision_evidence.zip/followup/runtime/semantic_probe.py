"""Score a separately calibrated local semantic model on synthetic Luna paraphrases."""

import argparse
from collections import Counter
import json
from math import log
import os
from pathlib import Path
from statistics import median, quantiles
from time import perf_counter_ns

import numpy as np

from corpus import DOMAINS, clue_for, make_cases
from estimator import fit
from replay import evaluation_rows


HERE = Path(__file__).resolve().parent
MODEL_NAME = 'Qwen/Qwen2.5-0.5B-Instruct'
DEFAULT_MODEL = (HERE.parents[2] / '20-ieeeacess-agent-2' / 'work' / 'revocation' / 'hf' / 'hub'
                 / 'models--Qwen--Qwen2.5-0.5B-Instruct' / 'snapshots' / '7ae557604adf67be50417f59c2c2f167def9a775')
LABELS = ('legend:0', 'legend:1', 'marker:0', 'marker:1', 'vote:0', 'vote:1', 'unknown')
LETTERS = 'ABCDEFG'
TEMPERATURES = (0.1, 0.15, 0.22, 0.33, 0.5, 0.67, 1, 1.5, 2, 3, 4, 6)
CONFIDENCE_MINIMUM = .75


def load(name):
    return json.loads((HERE / name).read_text(encoding='utf-8-sig'))


def likelihood(logits, temperature):
    scaled = np.asarray(logits) / temperature
    distributions = np.exp(scaled - scaled.max(axis=-1, keepdims=True))
    return distributions / distributions.sum(axis=-1, keepdims=True)


def prompt(text, domain):
    spec = DOMAINS[domain]
    marker1, marker2 = spec['markers']
    vote1, vote2 = spec['votes']
    secret = spec['secret_label']
    return [
        {'role': 'system', 'content': '你是中文句义分类器。严格按给定类别判断，只输出一个英文字母 A 到 G。'},
        {'role': 'user', 'content': (
            '以下是完全虚构的业务记录。根据语义而非字面匹配识别该句传达哪一类信息。'
            '近义描述保留原来的方向；只判断当前对象，忽略其他对象。不猜测没有说明的规则或事实。\n'
            f'本领域的目标问题：是否{secret}？\n'
            f'第一标记是「{marker1}」，第二标记是「{marker2}」。两个倾向的标准名字为「{vote1}」和「{vote2}」。\n'
            f'A 本批解释规则：{marker1}代表目标问题的否，{marker2}代表是。\n'
            f'B 本批解释规则：{marker1}代表目标问题的是，{marker2}代表否。\n'
            f'C 当前对象实际显示的标记为{marker1}，句子只报告标记，不提供标记含义规则。\n'
            f'D 当前对象实际显示的标记为{marker2}，句子只报告标记，不提供标记含义规则。\n'
            f'E 本路观察偏向「{vote1}」，句子没有报告颜色、形状等标记，也没有解释标记规则。\n'
            f'F 本路观察偏向「{vote2}」，句子没有报告颜色、形状等标记，也没有解释标记规则。\n'
            'G 没有上述明确含义、两种解释都成立，或同时提供多类信息。\n'
            f'待分类的句子：{text}\n类别：')},
    ]


def calibration_rows():
    rows = []
    for domain in DOMAINS:
        for label in LABELS[:-1]:
            kind, bit = label.split(':')
            for variant in range(2):
                rows.append((domain, clue_for(domain, kind, int(bit), variant, 'calibration'), label))
        m1, m2 = DOMAINS[domain]['markers']
        rows.extend(((domain, '收到，请更新材料登记时间。', 'unknown'),
                     (domain, f'这里提到的可能是{m1}也可能是{m2}，待核对。', 'unknown')))
    return rows


class LocalClassifier:
    def __init__(self, model_path, threads):
        os.environ['HF_HUB_OFFLINE'] = '1'
        os.environ['TRANSFORMERS_OFFLINE'] = '1'
        os.environ['TOKENIZERS_PARALLELISM'] = 'false'
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer

        if not model_path.is_dir() or not (model_path / 'config.json').is_file():
            raise FileNotFoundError(f'Local checkpoint is incomplete: {model_path}')
        torch.set_num_threads(threads)
        torch.set_num_interop_threads(1)
        self.torch = torch
        self.tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True, padding_side='left')
        self.model = AutoModelForCausalLM.from_pretrained(model_path, local_files_only=True, dtype=torch.bfloat16).eval()
        self.verbalizers = []
        for letter in LETTERS:
            variants = [self.tokenizer.encode(prefix + letter, add_special_tokens=False) for prefix in ('', ' ')]
            assert all(len(tokens) == 1 for tokens in variants)
            self.verbalizers.append(sorted({tokens[0] for tokens in variants}))
        assert len(set.union(*(set(group) for group in self.verbalizers))) == sum(map(len, self.verbalizers))

    def score(self, examples):
        formatted = [self.tokenizer.apply_chat_template(prompt(text, domain), tokenize=False,
                                                        add_generation_prompt=True, enable_thinking=False)
                     for domain, text in examples]
        inputs = self.tokenizer(formatted, padding=True, return_tensors='pt', add_special_tokens=False)
        with self.torch.inference_mode():
            raw = self.model(**inputs, use_cache=False, logits_to_keep=1).logits[:, -1, :].float()
            classes = self.torch.stack([raw[:, ids].logsumexp(dim=-1) for ids in self.verbalizers], dim=-1)
            mass = self.torch.exp(classes.logsumexp(dim=-1) - raw.logsumexp(dim=-1))
        return classes.numpy(), mass.numpy()


def duration(start):
    return (perf_counter_ns() - start) / 1e6


def latency(values):
    if not values:
        return None
    p95 = quantiles(values, n=100, method='inclusive')[94] if len(values) > 1 else values[0]
    return {'p50_ms': median(values), 'p95_ms': p95,
            'mean_ms': sum(values) / len(values)}


def summarize(rows, model):
    equivalent = [r for r in rows if r['equivalent']]
    return {'cases': len(rows), 'eligible': len(equivalent),
            'correct': sum(r[model]['prediction'] == r['target'] for r in equivalent),
            'incorrect_accepted': sum(r[model]['prediction'] not in (r['target'], 'unknown') for r in equivalent),
            'abstained_eligible': sum(r[model]['prediction'] == 'unknown' for r in equivalent),
            'abstained_all': sum(r[model]['prediction'] == 'unknown' for r in rows),
            'timings': latency([r[model]['latency_ms'] for r in rows])}


def save_checkpoint(out, data):
    temporary = out.with_suffix(out.suffix + '.tmp')
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    temporary.replace(out)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model-path', type=Path, default=DEFAULT_MODEL)
    parser.add_argument('--model-name', default=MODEL_NAME)
    parser.add_argument('--threads', type=int, default=6)
    parser.add_argument('--out', type=Path, default=HERE / 'semantic_probe_result.json')
    args = parser.parse_args()

    truth = {r['id']: r for r in load('新措辞真值.json')}
    answers = {r['id']: r['text'] for r in load('新措辞输出.json')}
    review = {r['id']: r for r in load('新措辞核验.json')}
    assert set(truth) == set(answers) == set(review) and len(truth) == 24
    calibration = calibration_rows()
    assert not set(answers.values()) & {text for _, text, _ in calibration}
    classifier = LocalClassifier(args.model_path, args.threads)
    print(f'Loaded {args.model_name} entirely offline', flush=True)

    cal_logits = []
    for offset in range(0, len(calibration), 8):
        block = calibration[offset:offset + 8]
        logits, _ = classifier.score([(domain, text) for domain, text, _ in block])
        cal_logits.extend(logits)
        print(f'Calibrated logits {min(offset + 8, len(calibration))}/{len(calibration)}', flush=True)
    targets = [LABELS.index(label) for _, _, label in calibration]

    def calibration_nll(temperature):
        predictions = likelihood(cal_logits, temperature)
        return -sum(log(max(float(p[t]), 1e-30)) for p, t in zip(predictions, targets, strict=True)) / len(targets)

    temperature = min(TEMPERATURES, key=calibration_nll)
    data = {'model': args.model_name, 'device': 'CPU', 'dtype': 'bfloat16', 'threads': args.threads,
            'status': 'in_progress', 'target_cases': len(truth),
            'calibration': {'rows': len(calibration), 'label_counts': dict(Counter(r[-1] for r in calibration)),
                            'temperature': temperature, 'nll_at_1': calibration_nll(1),
                            'nll_calibrated': calibration_nll(temperature), 'confidence_threshold': CONFIDENCE_MINIMUM},
            'scope': 'One prompt containing one synthetic phrase and public terminology. Confidence is conditional on seven letter labels. Single-request timing includes prompt rendering, tokenization and one forward pass; model loading is excluded.'}
    save_checkpoint(args.out, data | {'summary': None, 'rows': []})
    baseline = fit(evaluation_rows(make_cases(180, 12031, 'calibration')),
                   evaluation_rows(make_cases(80, 46733, 'calibration')))
    classifier.score([(calibration[0][0], calibration[0][1])])
    baseline.classify(calibration[0][1])
    scored = []
    for key, r in truth.items():
        text = answers[key]
        started = perf_counter_ns()
        logits, mass = classifier.score([(r['domain'], text)])
        probs = likelihood(logits, temperature)[0]
        index = int(np.argmax(probs))
        confidence = float(probs[index])
        prediction = LABELS[index] if confidence >= CONFIDENCE_MINIMUM else 'unknown'
        local_ms = duration(started)
        started = perf_counter_ns()
        component, p1, base_confidence = baseline.classify(text)
        base_prediction = f'{component}:{int(p1 > .5)}' if component in ('legend', 'marker', 'vote') else 'unknown'
        base_ms = duration(started)
        scored.append({'id': key, 'domain': r['domain'], 'target': f"{r['component']}:{r['bit']}", 'text': text,
                       'equivalent': review[key]['equivalent'],
                       'local': {'prediction': prediction, 'top_label': LABELS[index], 'confidence': confidence,
                                 'candidate_token_mass': float(mass[0]), 'latency_ms': local_ms},
                       'linear': {'prediction': base_prediction, 'confidence': base_confidence, 'latency_ms': base_ms}})
        data.update(status='complete' if len(scored) == len(truth) else 'in_progress', rows=scored,
                    summary={model: summarize(scored, model) for model in ('local', 'linear')})
        save_checkpoint(args.out, data)
        print(f'Scored {len(scored)}/{len(truth)}', flush=True)
    print(json.dumps(data['summary'], ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
