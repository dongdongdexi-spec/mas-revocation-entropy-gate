## Appendix A. Recorded Model Execution Protocol

Model outputs were collected on 25 November 2026. The workflow and coordinator model was OpenAI GPT-6 Luna (`gpt-6-luna`), and the blind observer was OpenAI GPT-6.2 Astra (`gpt-6.2-astra`). The provider's model pages verify the names and identifiers. [GPT-6 Luna](https://developers.openai.com/api/docs/models/gpt-6-luna) · [GPT-6.2 Astra](https://developers.openai.com/api/docs/models/gpt-6.2-astra)

For the principal Luna runs, the client launched the signed-in Codex App Server over standard I/O. It sent the following newline-delimited JSON messages. The request identifiers, empty working directory, thread identifier, and prompt text are runtime values. The runner checked the returned model at thread creation and retained the final agent message, session and turn identifiers, and available token usage. The supplement includes the runner and the archived prompts and outputs. [Codex App Server protocol](https://developers.openai.com/codex/app-server)

```jsonl
{"id":1,"method":"initialize","params":{"clientInfo":{"name":"synthetic_qif_benchmark","version":"1.0"},"capabilities":{"experimentalApi":true}}}
{"method":"initialized"}
{"id":2,"method":"thread/start","params":{"model":"gpt-6-luna","cwd":"<empty run directory>","sandbox":"read-only","approvalPolicy":"never","ephemeral":true,"config":{"model_reasoning_effort":"low"}}}
{"id":3,"method":"turn/start","params":{"threadId":"<thread ID>","input":[{"type":"text","text":"<archived prompt>"}],"model":"gpt-6-luna","effort":"low"}}
```

The blinded Astra assessment used isolated Codex subagent sessions with high reasoning effort. The supplemental archive preserves the sealed observer inputs and answers, and it identifies the three Luna trials completed via the fallback subagent interface. The client did not supply `temperature`, `top_p`, a maximum output length, or a pinned model snapshot in the requests above. Effective server-side decoding settings were unavailable in the retained records. The saved outputs support offline replay and rescoring. A new hosted run provides an independent replication subject to changes in hosted serving and sample variation.

