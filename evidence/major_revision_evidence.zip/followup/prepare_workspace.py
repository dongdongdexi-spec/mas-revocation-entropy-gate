from io import BytesIO
from pathlib import Path
from shutil import copyfile
from zipfile import ZipFile
import argparse

cli = argparse.ArgumentParser(description="Stage input files for the manuscript follow-up experiments.")
cli.add_argument("destination", type=Path)
args = cli.parse_args()
archive = Path(__file__).resolve().parent.parent
root = args.destination.resolve()
if root == archive or (root.exists() and any(root.iterdir())):
    cli.error("Choose an empty directory outside the extracted supplement.")
runtime = root / "work" / "revocation_qif_advanced"
fig_inputs = root / "outputs" / "撤权拼图四项升级实验"

def write(dest, content):
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(content)

def copy(src, dest):
    dest.parent.mkdir(parents=True, exist_ok=True)
    copyfile(src, dest)

with ZipFile(archive / "baseline" / "original_experiment_archive.zip") as original:
    prefix = "撤权拼图四项升级实验"
    for name in ("corpus.py","estimator.py","replay.py","ledger.py"):
        write(runtime / name, original.read(f"{prefix}/复算脚本/{name}"))
    for name in ("独立Luna会话.jsonl","正式200题种子.json"):
        write(runtime / "final_replay" / name, original.read(f"{prefix}/{name}"))
    for name in ("预算扫描_Luna.csv","逐步熵曲线_Luna.csv","自然语言实验结果.json"):
        write(fig_inputs / name, original.read(f"{prefix}/{name}"))
for p in (archive / "followup" / "runtime").iterdir():
    copy(p, runtime / p.name)
for p in (archive / "followup" / "paraphrase").iterdir():
    copy(p, root / "work" / "ieee_manuscript_followup" / "paraphrase" / p.name)
for name in ("heldout_messages.json","results.json"):
    copy(archive / "semantic" / name, root / "work" / "ieee_revision" / "semantic" / name)
copy(archive / "followup" / "ieee_figures.py", root / "work" / "ieee_revision" / "ieee_figures.py")
(root / "outputs" / "IEEE_Access_Revision").mkdir(parents=True, exist_ok=True)
print(root)
