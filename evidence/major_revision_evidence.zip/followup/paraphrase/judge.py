"""Offline small-LLM evidence classifier on the archived paraphrase and control sets."""

import argparse
from collections import Counter
from hashlib import sha256
from importlib.metadata import version
import json
from math import log
from pathlib import Path
import sys
from time import perf_counter_ns

import numpy as np


def sha(path):
    with path.open('rb') as stream:
        from hashlib import file_digest
        return file_digest(stream, 'sha256').hexdigest()


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--model', type=Path, required=True)
    cli.add_argument('--current-workspace', type=Path, default=Path.cwd())
    cli.add_argument('--threads', type=int, default=3)
    args = cli.parse_args()
    scratch = Path(__file__).resolve().parent
    work = args.current_workspace / 'work'
    runtime = work / 'revocation_qif_advanced'
    challenge = work / 'ieee_revision' / 'semantic' / 'heldout_messages.json'
    sys.path.insert(0, str(runtime))
    from semantic_probe import (
        CONFIDENCE_MINIMUM, LABELS, TEMPERATURES, LocalClassifier,
        calibration_rows, latency, likelihood, load, save_checkpoint,
    )

    rewrites = {r['id']: r['text'] for r in load('新措辞输出.json')}
    review = {r['id']: r['equivalent'] for r in load('新措辞核验.json')}
    originals = load('新措辞真值.json')
    tests = [
        {'id': r['id'], 'domain': r['domain'], 'text': rewrites[r['id']],
         'target': f"{r['component']}:{r['bit']}", 'cohort': 'rewrite',
         'equivalent': review[r['id']]}
        for r in originals
    ]
    challenge_rows = json.loads(challenge.read_text(encoding='utf-8-sig'))
    tests.extend({**row, 'target': 'unknown', 'cohort': 'nonassertive_control'}
                 for row in challenge_rows if row['type'] == 'unknown')
    assert Counter(x['cohort'] for x in tests) == {'rewrite': 24, 'nonassertive_control': 24}
    calibration = calibration_rows()
    assert not {r['text'] for r in tests} & {text for _, text, _ in calibration}
    out = scratch / 'judge-results.json'
    freeze = scratch / 'judge-protocol.json'
    protocol = {
        'checkpoint': 'Qwen/Qwen2.5-0.5B-Instruct',
        'checkpoint_revision': '7ae557604adf67be50417f59c2c2f167def9a775',
        'cpu_threads': args.threads,
        'dtype': 'bfloat16',
        'torch': version('torch'),
        'transformers': version('transformers'),
        'input_sha256': {p.name: sha(p) for p in
                         (runtime / 'semantic_probe.py', challenge,
                          runtime / '新措辞输出.json', runtime / '新措辞核验.json',
                          runtime / '新措辞真值.json')},
        'model_sha256': {p.name: sha(p) for p in args.model.glob('*') if p.is_file()},
        'temperature_grid': list(TEMPERATURES),
        'confidence_threshold': CONFIDENCE_MINIMUM,
        'calibration': calibration,
        'tests': tests,
        'decision': 'Find the highest-probability of seven letter labels. Output unknown unless its temperature-scaled conditional probability is at least 0.75.',
    }
    if freeze.exists():
        assert json.loads(freeze.read_text(encoding='utf-8')) == json.loads(json.dumps(protocol))
    else:
        save_checkpoint(freeze, protocol)
    classifier = LocalClassifier(args.model, args.threads)
    print('Loaded checkpoint offline', flush=True)
    cal_logits = []
    for start in range(0, len(calibration), 2):
        batch = calibration[start:start+2]
        raw, _ = classifier.score([(domain, text) for domain, text, _ in batch])
        cal_logits.extend(raw)
        if (start+2) % 8 == 0:
            print(f'Calibrated {start+2}/{len(calibration)}', flush=True)
    targets = [LABELS.index(label) for _, _, label in calibration]

    def nll(temperature):
        probabilities = likelihood(cal_logits, temperature)
        return -sum(log(max(float(row[target]), 1e-30))
                    for row, target in zip(probabilities, targets, strict=True)) / len(targets)

    temperature = min(TEMPERATURES, key=nll)
    scored = []
    run = {'status': 'in_progress', 'protocol_sha256': sha(freeze), 'temperature': temperature,
           'calibration_nll_at_1': nll(1), 'calibration_nll': nll(temperature), 'rows': scored}
    save_checkpoint(out, run)
    classifier.score([(calibration[0][0], calibration[0][1])])
    for row in tests:
        start = perf_counter_ns()
        logits, mass = classifier.score([(row['domain'], row['text'])])
        probs = likelihood(logits, temperature)[0]
        i = int(np.argmax(probs))
        prediction = LABELS[i] if probs[i] >= CONFIDENCE_MINIMUM else 'unknown'
        duration_ms = (perf_counter_ns() - start) / 1e6
        scored.append({**row, 'prediction': prediction, 'top_label': LABELS[i],
                       'confidence': float(probs[i]), 'candidate_token_mass': float(mass[0]),
                       'latency_ms': duration_ms})
        save_checkpoint(out, run)
        print(f'Scored {len(scored)}/{len(tests)}', flush=True)
    informative = [r for r in scored if r['cohort'] == 'rewrite' and r['equivalent']]
    non_equivalent = [r for r in scored if r['cohort'] == 'rewrite' and not r['equivalent']]
    controls = [r for r in scored if r['cohort'] == 'nonassertive_control']
    stats = {
        'meaning_preserving': len(informative),
        'correct_accepts': sum(r['prediction'] == r['target'] for r in informative),
        'wrong_accepts': sum(r['prediction'] not in ('unknown', r['target']) for r in informative),
        'informative_abstentions': sum(r['prediction'] == 'unknown' for r in informative),
        'nonassertive_controls': len(controls),
        'nonassertive_accepted': sum(r['prediction'] != 'unknown' for r in controls),
        'non_equivalent_prediction': non_equivalent[0]['prediction'],
        'mean_time_all': latency([r['latency_ms'] for r in scored]),
        'meaning_preserving_time': latency([r['latency_ms'] for r in informative]),
    }
    assert stats['meaning_preserving'] == sum(stats[k] for k in
                                             ('correct_accepts', 'wrong_accepts', 'informative_abstentions'))
    run.update(status='complete', summary=stats)
    save_checkpoint(out, run)
    print(stats, flush=True)


if __name__ == '__main__':
    main()
