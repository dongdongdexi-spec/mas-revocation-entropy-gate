"""Replace one evidence span per archived workflow and replay the release gate."""

import argparse
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import sys


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, allow_nan=False, indent=2) + '\n',
                    encoding='utf-8')


def sha(path):
    return sha256(path.read_bytes()).hexdigest()


def select_cases(cases, equivalents):
    """Match deterministically on the changed span's domain, type, and value."""
    used = set()
    matches = []
    for item in sorted(equivalents, key=lambda r: (r['domain'], r['kind'], r['bit'])):
        for case in cases:
            if case['id'] in used or case['domain'] != item['domain']:
                continue
            phase = 'pre' if item['kind'] == 'legend' else 'post'
            first = next((m for m in case['messages']
                          if m['phase'] == phase and m['component'] != 'neutral'), None)
            if first is not None and (first['component'], first['bit']) == (item['kind'], item['bit']):
                used.add(case['id'])
                matches.append({'rewrite_id': item['id'], 'case_id': case['id'], 'role': first['id'],
                                'component': item['kind'], 'domain': case['domain'],
                                'history': case['history'], 'phase': phase})
                break
        else:
            raise ValueError(f"missing a unique workflow for {item['id']}")
    return matches


def typed(component, bit):
    return {'component': component, 'bit': bit}


def replay(case, source, match, rewrites, predictions, budget, static, precision_domains,
           exact_risk, oracle_posterior, entropy, tolerance):
    target = rewrites[match['rewrite_id']]
    lookup = {(item['domain'], item['kind'], item['bit']): item
              for item in rewrites.values() if item['equivalent']}
    post = [row for row in source if row['phase'] == 'post']
    required = {row['id']: row['code'] for row in post if row['critical']}
    precision_role = next(row['id'] for row in post if row['component'] != 'neutral')
    precision_required = case['domain'] in precision_domains
    true_history = []
    estimated_history = []
    notes = []
    for row in source:
        if row['phase'] != 'pre' or row['component'] == 'neutral':
            continue
        truth = typed(row['component'], row['bit'])
        true_history.append(truth)
        if row['id'] == match['role']:
            pred = predictions.get(target['id'])
            if pred is not None and pred['component'] != row['component']:
                pred = None
            notes.append({'role': row['id'], 'text': row['text'].replace(row['clue'], target['text'], 1),
                          'true': truth, 'recognized': pred})
        else:
            pred = truth
            notes.append({'role': row['id'], 'text': row['text'], 'true': truth, 'recognized': pred})
        estimated_history.append(pred)

    received = set()
    precision_retained = False
    outputs = []
    for row in post:
        component = row['component']
        true = None if component == 'neutral' else typed(component, row['bit'])
        rewrite = row['id'] == match['role']
        predicted = true
        canonical_options = [typed(component, bit) for bit in (0, 1)]
        oracle_bound = None if true is None else exact_risk(case, true_history, canonical_options)
        predicted_bound = None
        if true is None:
            allow, reason = True, 'no_evidence'
        elif static:
            allow, reason = False, 'static_generalization'
        elif case['history'] == 'gap':
            allow, reason = False, 'detected_history_gap'
        elif None in estimated_history:
            allow, reason = False, 'unrecognized_history'
        else:
            if rewrite:
                public_options = [lookup.get((case['domain'], component, bit)) for bit in (0, 1)]
                predicted_options = [predictions.get(o['id']) if o is not None else None
                                     for o in public_options]
                predicted = predictions.get(target['id'])
            else:
                predicted_options = canonical_options
            certified = (None not in predicted_options and
                         {p['component'] for p in predicted_options} == {component} and
                         {p['bit'] for p in predicted_options} == {0, 1})
            if certified:
                predicted_bound = exact_risk(case, estimated_history, predicted_options)
                allow = predicted_bound <= budget + tolerance
                reason = 'within_budget' if allow else 'budget_guard'
            else:
                allow, reason = False, 'incomplete_or_unrecognized_alternative_set'
        if allow:
            output = row['text'].replace(row['clue'], target['text'], 1) if rewrite else row['text']
            if true is not None:
                assert predicted is not None
                true_history.append(true)
                estimated_history.append(predicted)
                precision_retained |= row['id'] == precision_role
        else:
            output = row['fact']
        if row['id'] in required and required[row['id']] in output:
            received.add(row['id'])
        actual = 1.0 - entropy(oracle_posterior(true_history, case['strength']))
        outputs.append({'role': row['id'], 'rewritten': rewrite, 'component': component,
                        'exact': allow, 'reason': reason, 'visible_text': output,
                        'estimated_envelope_bits': predicted_bound, 'true_envelope_bits': oracle_bound,
                        'actual_prefix_entropy_reduction': actual,
                        'envelope_violation': bool(allow and oracle_bound is not None and
                                                   oracle_bound > budget + tolerance),
                        'prefix_overshoot': actual > budget + tolerance})
    return {'case': case['id'], 'domain': case['domain'], 'history': case['history'],
            'rewrite_id': target['id'], 'changed_component': target['kind'],
            'precision_required': precision_required, 'precision_retained': precision_retained,
            'identifiers_satisfied': len(received) == len(required),
            'fields_satisfied': len(received) == len(required) and
                                (precision_retained or not precision_required),
            'pre_messages': notes, 'post_messages': outputs}


def summarize(rows):
    deliveries = [m for row in rows for m in row['post_messages']]
    evidence = [m for m in deliveries if m['component'] != 'neutral']
    return {'workflows': len(rows), 'identifiers_satisfied': sum(r['identifiers_satisfied'] for r in rows),
            'fields_satisfied': sum(r['fields_satisfied'] for r in rows),
            'precision_required_workflows': sum(r['precision_required'] for r in rows),
            'precision_fields_satisfied': sum(r['precision_required'] and r['precision_retained'] for r in rows),
            'post_deliveries': len(deliveries), 'post_evidence_deliveries': len(evidence),
            'exact_post_evidence_releases': sum(m['exact'] for m in evidence),
            'changed_post_evidence_attempts': sum(m['rewritten'] for m in evidence),
            'changed_post_evidence_exact': sum(m['rewritten'] and m['exact'] for m in evidence),
            'envelope_violations': sum(m['envelope_violation'] for m in evidence),
            'prefix_overshoots': sum(m['prefix_overshoot'] for m in deliveries),
            'workflows_with_prefix_overshoot': sum(any(m['prefix_overshoot'] for m in r['post_messages'])
                                                  for r in rows)}


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--current-workspace', type=Path, default=Path.cwd())
    args = cli.parse_args()
    scratch = Path(__file__).resolve().parent
    work = args.current_workspace / 'work'
    runtime = work / 'revocation_qif_advanced'
    sys.path.insert(0, str(runtime))
    from estimator import entropy
    from replay import PRECISION_DOMAINS, TOLERANCE, exact_risk, oracle_posterior, source_messages

    records = runtime / 'final_replay'
    source_path = records / '独立Luna会话.jsonl'
    seed_path = records / '正式200题种子.json'
    legacy_path = work / 'ieee_revision' / 'semantic' / 'results.json'
    truth_path = runtime / '新措辞真值.json'
    answers_path = runtime / '新措辞输出.json'
    review_path = runtime / '新措辞核验.json'
    cases = sorted(read(seed_path), key=lambda c: c['id'])
    natural = {r['id']: r for r in map(json.loads, source_path.read_text(encoding='utf-8-sig').splitlines())}
    assert len(cases) == len(natural) == 200
    truths = read(truth_path)
    text = {r['id']: r['text'] for r in read(answers_path)}
    semantic_equivalence = {r['id']: r['equivalent'] for r in read(review_path)}
    rewrites = {r['id']: {**r, 'kind': r['component'], 'text': text[r['id']],
                         'equivalent': semantic_equivalence[r['id']]} for r in truths}
    eligible = [row for row in rewrites.values() if row['equivalent']]
    assert len(eligible) == 23
    matches = select_cases(cases, eligible)
    assert len({m['case_id'] for m in matches}) == 23
    paths = (source_path, seed_path, legacy_path, truth_path, answers_path, review_path)
    protocol = {'inputs_sha256': {path.name: sha(path) for path in paths},
                'matches': matches, 'budgets_bits': [0.0, 0.5],
                'scope': 'Post hoc matched substitution on archived six-role workflows. Keep the business span and source wrapper, replace one natural-language evidence span, and treat unchanged registered fields as prevalidated. Sensitive text originates only in synthetic fixtures.',
                'match_rule': 'For each vetted rewrite, sorted by domain, component and bit, use the first unused sorted archived workflow matching the first pre- or post-revocation evidence item. Append no extra message. Keep original timing, task fields, cue direction and ground truth.',
                'paired_check': 'For a rewritten post-revocation slot, require both synthetic input alternatives to be present in the equivalent paraphrase pool and map to distinct directions of the registered component. Carry parsed directions into the receiver history. On any unknown or detectable gap, deliver only the authorized business field.'}
    frozen = scratch / 'replay-protocol.json'
    if frozen.exists():
        assert read(frozen) == protocol
    else:
        save(frozen, protocol)

    legacy = read(legacy_path)
    classifiers = {'fixed_field_generalization': {}, 'typed_reference': {
        r['id']: typed(r['kind'], r['bit']) for r in eligible}}
    for classifier in ('relation_parser', 'lexical'):
        classifiers[classifier] = {
            r['id']: typed(r['predicted_type'], int(r['p1'] > .5))
            for r in legacy[classifier]['legacy_24']['rows'] if r['predicted_type'] != 'unknown'}
    judge_path = scratch / 'judge-results.json'
    judge = read(judge_path) if judge_path.is_file() else None
    if judge is not None:
        judged_rewrites = {r['id']: r for r in judge['rows'] if r['cohort'] == 'rewrite'}
        if set(judged_rewrites) == set(rewrites):
            classifiers['small_llm'] = {}
            for row in judged_rewrites.values():
                if row['prediction'] != 'unknown':
                    component, bit = row['prediction'].split(':')
                    classifiers['small_llm'][row['id']] = typed(component, int(bit))
    data = {'protocol_sha256': sha(frozen), 'changed_slots': dict(Counter(x['component'] for x in matches)),
            'history_states': dict(Counter(x['history'] for x in matches)),
            'results': {}}
    by_id = {c['id']: c for c in cases}
    for method, predictions in classifiers.items():
        rows = {}
        for budget in protocol['budgets_bits']:
            scored = []
            for match in matches:
                case = by_id[match['case_id']]
                origin, src = source_messages(case, natural)
                assert origin == 'luna'
                assert next(m for m in src if m['id'] == match['role'])['clue']
                scored.append(replay(case, src, match, rewrites, predictions, budget,
                                     method == 'fixed_field_generalization', PRECISION_DOMAINS,
                                     exact_risk, oracle_posterior, entropy, TOLERANCE))
            rows[str(budget)] = {'summary': summarize(scored), 'rows': scored}
        data['results'][method] = rows
    save(scratch / 'replay-results.json', data)
    for method, rows in data['results'].items():
        print(method, {budget: row['summary'] for budget, row in rows.items()})


if __name__ == '__main__':
    main()
