"""Render the two revocation study figures at their 7.15-inch publication width."""

import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
from matplotlib import pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch


ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "outputs" / "撤权拼图四项升级实验"
DESTINATION = ROOT / "outputs" / "IEEE_Access_Revision"
WIDTH = 7.15
WIDTH_PT = WIDTH * 72
INK = "#203245"
BLUE = "#28588b"
GREEN = "#08715a"
AMBER = "#9a521e"
PURPLE = "#79436d"
DPI = 400


def save_figure(figure, name):
    for extension in ("png", "pdf"):
        path = DESTINATION / f"{name}_ieee.{extension}"
        figure.savefig(path, dpi=DPI, facecolor="white")
    plt.close(figure)


def architecture():
    height = 255
    figure = plt.figure(figsize=(WIDTH, height / 72), facecolor="white")
    axes = figure.add_axes((0, 0, 1, 1), xlim=(0, WIDTH_PT), ylim=(0, height))
    axes.set_axis_off()

    def label(x, y, text, size=8, color=INK, bold=False, align="center"):
        axes.text(x, y, text, ha=align, va="center", fontsize=size,
                  color=color, weight="bold" if bold else "normal", zorder=5)

    def box(x, y, width, height, text, fill, edge, size=8, bold=False, dashed=False):
        axes.add_patch(FancyBboxPatch(
            (x, y), width, height, boxstyle="round,pad=0,rounding_size=5",
            facecolor=fill, edgecolor=edge, linewidth=1,
            linestyle="--" if dashed else "-", zorder=1,
        ))
        if text:
            label(x + width / 2, y + height / 2, text, size, bold=bold)

    def arrow(start, end, color=INK, dashed=False):
        axes.add_patch(FancyArrowPatch(
            start, end, arrowstyle="-|>", mutation_scale=8, color=color,
            linewidth=1, linestyle="--" if dashed else "-",
            shrinkA=1, shrinkB=1, zorder=2,
        ))

    def dashed_path(points):
        x, y = zip(*points, strict=True)
        axes.plot(x, y, color=INK, linewidth=.9, linestyle="--", zorder=2)

    light_blue, light_green, light_amber, light_gray = "#eaf3fb", "#e7f4ef", "#fff3e6", "#f5f7fa"
    box(10, 189, 104, 37, "Coordinator\nSole material intake", light_blue, BLUE, 8.2, True)
    box(10, 91, 104, 72, "", "#f9fcff", BLUE)
    label(62, 151, "Six worker agents", 8, bold=True)
    for index, agent in enumerate("ABCDEF"):
        box(24 + index % 3 * 27, 99 + (1 - index // 3) * 21,
            22, 16, agent, light_blue, BLUE, 7.6)
    arrow((62, 188), (62, 164), BLUE)
    label(67, 176, "Scoped tasks", 7.6, BLUE, align="left")

    box(134, 53, 249, 180, "", "#fcfdfe", INK, dashed=True)
    label(259, 222, "Gateway critical section", 9, bold=True)
    box(147, 169, 100, 36, "Check receipt prefix\nagainst watermark", light_gray, INK)
    box(269, 169, 100, 36, "Estimate maximum\ncandidate risk", light_blue, BLUE)
    box(147, 110, 100, 37, "Verified business-\nonly fallback", light_amber, AMBER)
    box(269, 110, 100, 37, "Select variant and\nrecord reservation", light_green, GREEN)
    box(147, 68, 100, 25, "Receipt cache and\npending state", light_gray, INK, 7.6)
    arrow((115, 130), (146, 183), BLUE)
    arrow((248, 187), (268, 187))
    label(258, 211, "Complete", 7.6)
    arrow((197, 168), (197, 148), AMBER)
    label(202, 157, "Gap", 7.6, AMBER, align="left")
    arrow((248, 129), (268, 129), AMBER)
    arrow((319, 168), (319, 148))
    arrow((316, 109), (248, 82), GREEN)
    label(290, 82, "Reserve", 7.6, GREEN)
    dashed_path([(147, 80), (141, 80), (141, 176)])
    arrow((141, 176), (147, 176), dashed=True)

    box(401, 169, 104, 36, "Trusted delivery source\nMonotone watermark", light_gray, INK, 7.4, True)
    box(401, 110, 104, 37, "Recipient\nVisible delivery", light_green, GREEN, 8, True)
    arrow((370, 129), (400, 129), GREEN)
    label(385, 151, "Commit", 7.6, GREEN)
    arrow((453, 148), (453, 168), dashed=True)
    label(458, 158, "Event", 7.6, align="left")
    dashed_path([(453, 206), (453, 238), (197, 238)])
    arrow((197, 238), (197, 206), dashed=True)
    label(326, 246, "Trusted watermark", 7.6)
    dashed_path([(453, 109), (453, 38), (197, 38)])
    arrow((197, 38), (197, 67), dashed=True)
    label(325, 26, "Receipt recorded after visible commit", 7.6)
    save_figure(figure, "architecture")


def read_csv(name):
    with (DATA / name).open(encoding="utf-8-sig", newline="") as source:
        return list(csv.DictReader(source))


def budget_sweep():
    trials = read_csv("预算扫描_Luna.csv")
    curves = read_csv("逐步熵曲线_Luna.csv")
    summary = json.loads((DATA / "自然语言实验结果.json").read_text(encoding="utf-8"))["summary"]
    figure, (left, right) = plt.subplots(1, 2, figsize=(WIDTH, 3.26), facecolor="white")
    figure.subplots_adjust(left=.095, right=.979, bottom=.335, top=.905, wspace=.34)

    for mode, title, color, line in (
        ("online", "Local-history only", PURPLE, "--"),
        ("robust", "Integrity-aware", GREEN, "-"),
    ):
        series = [row for row in trials if row["strategy"] == mode]
        x = [100 * float(row["expected_bayes_reconstruction_rate"]) for row in series]
        y = [100 * float(row["task_completion_rate"]) for row in series]
        left.plot(x, y, marker="o", ms=4, color=color, linestyle=line, lw=1.25, label=title)
        positions = {}
        for xv, yv, row in zip(x, y, series, strict=True):
            positions.setdefault((xv, yv), []).append(row["epsilon_bits"])
        for (xv, yv), budgets in positions.items():
            if mode == "online" and "∞" in budgets:
                continue
            if "∞" in budgets:
                offset, alignment = (-1, -16), "right"
            elif mode == "online" or "0.25" in budgets:
                offset, alignment = (4, -11), "left"
            else:
                offset, alignment = (4, 7), "left"
            left.annotate("/".join(budgets), (xv, yv), xytext=offset,
                          textcoords="offset points", ha=alignment, color=color, fontsize=7.5)

    fixed = summary["static"]
    left.scatter(100 * fixed["expected_bayes_reconstruction_rate"],
                 100 * fixed["task_completion_rate"],
                 color=BLUE, marker="s", s=15, label="Fixed field generalization", zorder=3)
    left.set(xlabel="Bayesian reconstruction probability (%)",
             ylabel="Required fields satisfied (%)",
             title="(a) Privacy and field satisfaction",
             xlim=(47, 89), ylim=(45, 105), xticks=[50, 60, 70, 80],
             yticks=[50, 60, 70, 80, 90, 100])

    for mode, title, color, marker in (
        ("label", "Explicit labels", AMBER, "o"),
        ("robust_05", "Integrity-aware, 0.5 bit", GREEN, "^"),
        ("robust_0", "Integrity-aware, 0 bit", BLUE, "s"),
    ):
        series = [row for row in curves if row["strategy"] == mode]
        assert len(series) == 7 and all(int(row["cases"]) == 200 for row in series)
        right.plot([int(row["stage"]) for row in series],
                   [float(row["mean_entropy_drop_bits"]) for row in series],
                   label=title, color=color, marker=marker, ms=3.7, lw=1.25)
    right.set(xlabel="Post-revocation handoff",
              ylabel="Mean entropy reduction (bits)",
              title="(b) Entropy across deliveries",
              xticks=range(7), ylim=(-.04, 1.02))

    for axes in (left, right):
        axes.grid(alpha=.22, linewidth=.6)
        axes.set_axisbelow(True)
        axes.spines[["top", "right"]].set_visible(False)
        axes.tick_params(labelsize=7.5, width=.65)
        axes.legend(loc="upper left", bbox_to_anchor=(0, -.31),
                    borderaxespad=0, frameon=False, fontsize=7.5)
    save_figure(figure, "budget_sweep")


if __name__ == "__main__":
    plt.rcParams.update({
        "pdf.fonttype": 42,
        "font.family": "DejaVu Sans",
        "axes.titlesize": 9,
        "axes.labelsize": 8,
        "text.color": INK,
        "axes.labelcolor": INK,
        "xtick.color": INK,
        "ytick.color": INK,
    })
    architecture()
    budget_sweep()
