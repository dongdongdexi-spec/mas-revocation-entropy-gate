"""Draw the registered evidence gate and its trust boundary."""

from pathlib import Path
import argparse
import matplotlib

matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch


def draw(destination):
    fig, ax = plt.subplots(figsize=(13.9, 6.1), facecolor='#ffffff')
    ax.set(xlim=(0, 15), ylim=(0, 7.2))
    ax.axis('off')
    fig.subplots_adjust(left=.008, right=.992, top=.99, bottom=.01)
    ink = '#183045'
    navy, blue, green, amber = '#364e62', '#225e92', '#247360', '#9b6228'

    def box(x, y, w, h, label, face, edge, size=10, bold=False, style='solid'):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.035,rounding_size=.11',
                                    facecolor=face, edgecolor=edge, linewidth=1.35, linestyle=style))
        if label:
            ax.text(x + w / 2, y + h / 2, label, ha='center', va='center',
                    color=ink, fontsize=size, weight='semibold' if bold else 'normal')

    def arrow(start, end, color=navy, bend=0, style='solid', width=1.45):
        ax.add_patch(FancyArrowPatch(start, end, arrowstyle='-|>', color=color, mutation_scale=13,
                                     linewidth=width, connectionstyle=f'arc3,rad={bend}', linestyle=style,
                                     shrinkA=2, shrinkB=2))

    def note(x, y, msg, color=navy, align='center'):
        ax.text(x, y, msg, ha=align, va='center', fontsize=9, color=color)

    light_blue, light_green, light_amber, light_gray = '#eaf4fc', '#e8f5ef', '#fff4e3', '#f6f8fa'
    box(.25, 5.72, 2.61, .97, 'Coordinator\nSingle material intake', light_blue, blue, 11, True)
    box(.25, 3.26, 2.61, 1.82, '', '#f9fcff', blue)
    ax.text(1.55, 4.78, 'Six downstream agents', ha='center', va='center', fontsize=10.5, weight='semibold', color=ink)
    for idx, char in enumerate('ABCDEF'):
        xx = .52 + (idx % 3) * .72
        yy = 4.03 - .53 * (idx // 3)
        box(xx, yy, .59, .33, char, light_blue, blue, 9)
    arrow((1.55, 5.7), (1.55, 5.09), blue)
    note(1.86, 5.37, 'Scoped tasks', blue, 'left')

    box(3.7, 1.45, 7.58, 5.24, '', '#fcfdfe', navy, style='dashed')
    ax.text(7.85, 6.35, 'Gateway critical section',
            ha='center', va='center', fontsize=12, weight='semibold', color=ink)
    box(4.07, 4.86, 2.83, .87, 'Check the receipt prefix\nagainst the watermark', light_gray, navy)
    box(7.32, 4.86, 3.50, .87, 'Evidence estimator and\nmaximum candidate risk', light_blue, blue)
    box(4.07, 3.13, 2.83, .87, 'Authorized business-only\nfallback', light_amber, amber)
    box(7.32, 3.13, 3.50, .87, 'Select the release variant\nand record its reservation', light_green, green)
    box(4.07, 1.82, 2.83, .72, 'Receipt cache and pending state', light_gray, navy, 9)

    arrow((2.88, 4.39), (4.02, 5.50), blue)
    note(3.29, 4.08, 'Proposed', blue)
    note(3.29, 3.83, 'release', blue)
    arrow((6.91, 5.30), (7.30, 5.30))
    note(7.10, 5.99, 'Complete history')
    arrow((5.49, 4.83), (5.49, 4.02), amber)
    note(5.78, 4.43, 'Gap detected', amber, 'left')
    arrow((6.91, 3.56), (7.30, 3.56), amber)
    arrow((9.09, 4.83), (9.09, 4.02))
    arrow((8.31, 3.09), (6.96, 2.24), green)
    note(7.91, 2.49, 'Reserve', green)
    ax.plot([4.06, 3.88, 3.88], [2.19, 2.19, 5.05], linestyle='--', color=navy, linewidth=1.1)
    arrow((3.88, 5.05), (4.06, 5.05), navy, style='dashed')

    box(11.89, 5.08, 2.87, .92, 'Trusted delivery source\nMonotone watermark', light_gray, navy, 10, True)
    box(11.89, 3.13, 2.87, .87, 'Recipient\nVisible delivery', light_green, green, 10.5, True)
    arrow((10.84, 3.56), (11.86, 3.56), green)
    note(11.55, 4.12, 'Commit', green)
    arrow((13.32, 4.04), (13.32, 5.05), navy, style='dashed')
    note(13.52, 4.54, 'Delivery event', navy, 'left')
    ax.plot([11.88, 11.59, 11.59, 5.51], [5.56, 5.56, 6.91, 6.91],
            color=navy, linestyle='--', linewidth=1.2)
    arrow((5.51, 6.89), (5.51, 5.75), navy, style='dashed')
    note(8.79, 7.06, 'Trusted watermark')
    ax.plot([14.40, 14.40, 5.51], [3.1, .84, .84], color=navy, linestyle='--', linewidth=1.2)
    arrow((5.51, .84), (5.51, 1.80), navy, style='dashed')
    note(9.80, .59, 'Receipt recorded after visible commit')
    fig.savefig(destination, dpi=240, facecolor=fig.get_facecolor())
    plt.close(fig)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('destination', type=Path)
    args = parser.parse_args()
    args.destination.parent.mkdir(parents=True, exist_ok=True)
    draw(args.destination)
