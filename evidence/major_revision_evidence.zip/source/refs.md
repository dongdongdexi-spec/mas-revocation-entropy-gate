## References

1. V. Patil, E. Stengel-Eskin, and M. Bansal, “The sum leaks more than its parts: Compositional privacy risks and mitigations in multi-agent collaboration,” arXiv:2509.14284, 2025. [Preprint][patil]
2. F. El Yagoubi, G. Badu-Marfo, and R. Al Mallah, “AgentLeak: A benchmark for internal-channel privacy leakage in multi-agent LLM systems,” arXiv:2602.11510, ver. 3, 2026. [Preprint][agentleak]
3. B. W. Lampson, “Protection,” in *Proc. 5th Princeton Symp. Information Sciences and Systems*, 1971, pp. 437–443, reprinted in *SIGOPS Oper. Syst. Rev.*, vol. 8, no. 1, pp. 18–24, 1974. [Reprint][lampson]
4. J. H. Saltzer and M. D. Schroeder, “The protection of information in computer systems,” *Proc. IEEE*, vol. 63, no. 9, pp. 1278–1308, 1975. [Publisher][saltzer]
5. R. S. Sandhu, E. J. Coyne, H. L. Feinstein, and C. E. Youman, “Role-based access control models,” *Computer*, vol. 29, no. 2, pp. 38–47, 1996. [Publisher][rbac]
6. Å. Hagström, S. Jajodia, F. Parisi-Presicce, and D. Wijesekera, “Revocations—A classification,” in *Proc. 14th IEEE Comput. Security Foundations Workshop*, 2001, pp. 44–58. [Proceedings program][hagstrom]
7. A. Birgisson, J. G. Politz, Ú. Erlingsson, A. Taly, M. Vrable, and M. Lentczner, “Macaroons: Cookies with contextual caveats for decentralized authorization in the cloud,” in *Proc. Network and Distributed System Security Symp. (NDSS)*, 2014, doi: 10.14722/ndss.2014.23212. [Proceedings][macaroons]
8. Eclipse Biscuit, “Specifications.” [Project specification][biscuit]
9. R. Pang et al., “Zanzibar: Google’s consistent, global authorization system,” in *Proc. USENIX Annu. Tech. Conf. (ATC)*, 2019, pp. 33–46. [Proceedings][zanzibar]
10. T. Lodderstedt, S. Dronia, and M. Scurtescu, “OAuth 2.0 token revocation,” RFC 7009, 2013. [RFC Editor][rfc7009]
11. M. B. Jones, A. Nadalin, B. Campbell, J. Bradley, and C. Mortimore, “OAuth 2.0 token exchange,” RFC 8693, 2020. [RFC Editor][rfc8693]
12. L. Liu, H. Yu, and X. Jiang, “VERA: Authority-preserving edge revocation for federated AI-agent workflows,” arXiv:2608.30091, 2026. [Preprint][vera]
13. B. Ammanaghatta Shivakumar, S. Priya, and P. Gao, “Agenra: A language and verified core for stateful LLM agent authorization,” arXiv:2608.22868, ver. 2, 2026. [Preprint][agenra]
14. D. E. Denning, “A lattice model of secure information flow,” *Commun. ACM*, vol. 19, no. 5, pp. 236–243, 1976. [Publisher][denning]
15. A. C. Myers and B. Liskov, “A decentralized model for information flow control,” in *Proc. 16th ACM Symp. Operating Systems Principles (SOSP)*, 1997, pp. 129–142. [Author manuscript][myers]
16. N. Zeldovich, S. Boyd-Wickizer, E. Kohler, and D. Mazières, “Making information flow explicit in HiStar,” in *Proc. 7th USENIX Symp. Operating Systems Design and Implementation (OSDI)*, 2006. [Proceedings][histar]
17. M. Krohn et al., “Information flow control for standard OS abstractions,” in *Proc. 21st ACM Symp. Operating Systems Principles (SOSP)*, 2007, pp. 321–334. [Publisher][flume]
18. N. Zeldovich, S. Boyd-Wickizer, and D. Mazières, “Securing distributed systems with information flow control,” in *Proc. 5th USENIX Symp. Networked Systems Design and Implementation (NSDI)*, 2008. [Proceedings][dstar]
19. A. Sabelfeld and D. Sands, “Declassification: Dimensions and principles,” *J. Comput. Security*, vol. 17, no. 5, pp. 517–548, 2009, doi: 10.3233/JCS-2009-0352. [Publisher][declass]
20. A. C. Myers, A. Sabelfeld, and S. Zdancewic, “Enforcing robust declassification,” in *Proc. 17th IEEE Comput. Security Foundations Workshop*, 2004. [Author manuscript][robustdeclass]
21. C. E. Shannon, “A mathematical theory of communication,” *Bell Syst. Tech. J.*, vol. 27, no. 3, pp. 379–423, 1948. [Publisher][shannon]
22. G. Smith, “On the foundations of quantitative information flow,” in *Proc. Int. Conf. Foundations of Software Science and Computational Structures (FoSSaCS)*, 2009, pp. 288–302. [Publisher][smith]
23. M. S. Alvim, K. Chatzikokolakis, A. McIver, C. Morgan, C. Palamidessi, and G. Smith, *The Science of Quantitative Information Flow*. Cham, Switzerland, Springer, 2020. [Publisher][alvimbook]
24. M. S. Alvim, K. Chatzikokolakis, C. Palamidessi, and G. Smith, “Measuring information leakage using generalized gain functions,” in *Proc. IEEE 25th Comput. Security Foundations Symp. (CSF)*, 2012, pp. 265–279. [Publisher][gain]
25. Y. Kawamoto, K. Chatzikokolakis, and C. Palamidessi, “Compositionality results for quantitative information flow,” in *Proc. 11th Int. Conf. Quantitative Evaluation of Systems (QEST)*, 2014, pp. 368–383. [Authors’ research summary][composition]
26. S. Asif and M. Mohammadi Amiri, “Information-theoretic privacy control for sequential multi-agent LLM systems,” arXiv:2603.05520, 2026. [Preprint][asif]
27. Y. Gong et al., “Opacity is not privacy: Information-constrained latent communication for multi-agent LLM systems,” in *Proc. Conf. Empirical Methods in Natural Language Processing (EMNLP)*, 2026, pp. 49695–49717, doi: 10.18653/2026.emnlp-main.2186. [Proceedings][gong]
28. N. Palumbo et al., “Formal policy enforcement for agentic systems,” arXiv:2602.16708, ver. 4, 2026. [Preprint][pcas]
29. M. Shim et al., “Confuse the model, control the flow: Understanding and mitigating privacy leakage from LLM agents with information flow control,” arXiv:2609.14003, 2026. [Preprint][flowseal]
30. A. Kravchenko, V. Liventsev, I. Konstantinov, I. Iskhakov, and M. Kukuy, “APPA: Recoverable information-flow control for real-world LLM agents,” arXiv:2607.24625, ver. 2, 2026. [Preprint][appa]
31. D. Girrens and G. Wang, “SPA: Securing persistent LLM agents across queries with plan-first information-flow control,” arXiv:2608.27234, ver. 2, 2026. [Preprint][spa]
32. Y. Shao, T. Li, W. Shi, Y. Liu, and D. Yang, “PrivacyLens: Evaluating privacy norm awareness of language models in action,” in *Advances in Neural Information Processing Systems*, vol. 37, 2024. [Proceedings][privacylens]
33. OpenAI, “Codex.” [Product documentation][codex]

[patil]: https://arxiv.org/abs/2509.14284
[agentleak]: https://arxiv.org/abs/2602.11510v3
[lampson]: https://web.eecs.umich.edu/~ryanph/jhu/cs318/fall19/readings/lampson.pdf
[saltzer]: https://doi.org/10.1109/PROC.1975.9939
[rbac]: https://doi.org/10.1109/2.485845
[hagstrom]: https://www.ieee-security.org/CSFWweb/Programs/program_csfw14.html
[macaroons]: https://www.ndss-symposium.org/ndss2014/ndss-2014-programme/macaroons-cookies-contextual-caveats-decentralized-authorization-cloud/
[biscuit]: https://doc.biscuitsec.org/reference/specifications.html
[zanzibar]: https://www.usenix.org/conference/atc19/presentation/pang
[rfc7009]: https://www.rfc-editor.org/rfc/rfc7009.html
[rfc8693]: https://www.rfc-editor.org/rfc/rfc8693.html
[vera]: https://arxiv.org/abs/2608.30091
[agenra]: https://arxiv.org/abs/2608.22868v2
[denning]: https://doi.org/10.1145/360051.360056
[myers]: https://www.cs.cornell.edu/andru/papers/iflow-sosp97/
[histar]: https://www.usenix.org/conference/osdi-06/making-information-flow-explicit-histar
[flume]: https://doi.org/10.1145/1294261.1294293
[dstar]: https://www.usenix.org/conference/nsdi-08/securing-distributed-systems-information-flow-control
[declass]: https://doi.org/10.3233/JCS-2009-0352
[robustdeclass]: https://www.cs.cornell.edu/andru/papers/csfw04.pdf
[shannon]: https://doi.org/10.1002/j.1538-7305.1948.tb01338.x
[smith]: https://doi.org/10.1007/978-3-642-00596-1_21
[alvimbook]: https://doi.org/10.1007/978-3-319-96131-6
[gain]: https://doi.org/10.1109/CSF.2012.26
[composition]: https://radar.inria.fr/report/2014/comete/uid33.html
[asif]: https://arxiv.org/abs/2603.05520
[gong]: https://aclanthology.org/2026.emnlp-main.2186/
[pcas]: https://arxiv.org/abs/2602.16708v4
[flowseal]: https://arxiv.org/abs/2609.14003
[appa]: https://arxiv.org/abs/2607.24625v2
[spa]: https://arxiv.org/abs/2608.27234v2
[privacylens]: https://proceedings.neurips.cc/paper_files/paper/2024/hash/a2a7e58309d5190082390ff10ff3b2b8-Abstract-Datasets_and_Benchmarks_Track.html
[codex]: https://openai.com/codex/
