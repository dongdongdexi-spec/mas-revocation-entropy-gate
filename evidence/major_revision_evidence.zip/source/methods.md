## IV. Schema-Registered Shared Entropy Gate

The gateway mediates registered business and evidence fields. The schema defines recognizable evidence types, their allowed values, and which business fields can be delivered independently. A downstream agent can write natural-language text around these fields. The policy and its evidence model are defined over the registered fields and the resulting delivery history.

![Coordinator, six downstream agents, the gateway critical section, and the trusted delivery source.](architecture.png)

**Fig. 1.** The coordinator delegates scoped tasks to six agents. The gateway checks the recorded delivery prefix against a trusted watermark, evaluates the proposed field at the available granularity, and reserves the selected variant. A detected gap sends the proposal to the verified business-only path. The receipt cache is updated after delivery.

### A. Posterior Update and Evidence Semantics

Let $L$ be the registered legend and $M$ the observed mark in a deterministic case. With a uniform secret and independent uniform legend, $M=L\oplus S$. Observing only one of $L$ and $M$ leaves the posterior uniform. Given both values,

$$
\Pr(S=1\mid L=\ell,M=m)=\mathbf{1}[\ell\oplus m=1].
$$

For registered soft observations $v_i\in\{0,1\}$, let $\rho_i=\Pr(v_i=S\mid S)$ be the generating reliability. The experiments hold the observation-generating reliability fixed. The gateway uses an assumed reliability $\widehat{\rho}_i$. With conditionally independent evidence and initial posterior $p_0$ before the soft observations, the update for known directions is

$$
\log\frac{\widehat p_t}{1-\widehat p_t}
=\log\frac{p_0}{1-p_0}+
\sum_i (2v_i-1)\log\frac{\widehat{\rho}_i}{1-\widehat{\rho}_i}.
$$

When the classifier assigns probability $\pi_i$ to evidence direction 1, the implementation uses $u_i=(1-\widehat{\rho}_i)+(2\widehat{\rho}_i-1)\pi_i$ and adds $\log\bigl(u_i/(1-u_i)\bigr)$ to the log odds. At a single observed direction, an initially uniform secret has posterior entropy $h_2(\rho_i)$ under the reference model. The exact reference enumerates the binary secret, hidden legend, and likelihood of the registered observations. It scores with the true reliability in all sensitivity conditions.

The original lexical estimator uses Chinese character features and domain vocabulary in a logistic classifier, with temperature calibration on a separate set. The proposed lightweight comparison uses a local relation parser with an explicit alias registry. It normalizes registered aliases, separates clauses, checks the two parts of legend relations, and extracts asserted marker or vote directions. Unsupported or ambiguous patterns can trigger abstention. Both estimators use the same posterior update. Section VI-E reports the lexical model, the relation parser, and a resource-matched check with shared alias information if available.

### B. Candidate Envelope and Local Generalization

Revocation activates the policy budget $\varepsilon$ for the recipient scope. For a public slot with allowed alternative set $\mathcal{A}_t$ and reconstructed history $h_{t-1}$, the gateway estimates the maximum cumulative entropy reduction over the registered values and renderings,

$$
\widehat U_t=\max_{a\in\mathcal{A}_t}
\left[\widehat H(S\mid h_0)-\widehat H(S\mid h_{t-1},a)\right].
$$

The policy preserves the full candidate if the evidence is recognized and $\widehat U_t\le\varepsilon$. Otherwise, it selects the verified business-only variant when one is available. The prototype emits the registered business field in this variant and omits the clue and its natural-language wrapper. Under fixed history and a fixed public slot, evaluating all candidate values before choosing the granularity keeps that choice independent of the actual current clue value in the registered model. The estimator's envelope is approximate. A uniform bound on estimation error for unrestricted text has yet to be established.

**Notation used by the gate**

| Symbol | Meaning |
|---|---|
| $S$ and $t_0$ | Revoked secret and the revocation time |
| $h_0$ and $z_{1:t}$ | Recipient-visible history at revocation and the subsequent visible prefix |
| $h_{t-1}$ | Gateway reconstruction of the recipient view before the next release |
| $R_t$ and $q_t$ | Realized entropy reduction and the optimal one-try guessing probability |
| $L$, $M$, and $v_i$ | Legend, mark, and registered soft evidence direction |
| $\rho_i$ and $\widehat{\rho}_i$ | True observation reliability and reliability assumed by the estimator |
| $\mathcal{A}_t$, $\widehat U_t$, and $\varepsilon$ | Registered alternatives, estimated candidate envelope, and configured budget |

### C. Receipt Verification and Reservation

The trusted delivery source publishes a monotone watermark for each recipient and session. Under the shared lock, the prototype checks that its receipt cache covers the committed prefix and incorporates earlier pending reservations into the next decision. Missing or inconsistent receipts and unavailable watermarks select the business-only variant if independently verified. Duplicate receipts are idempotent. For the budget-sweep replay, a detected gap instead contributes an upper bound of one bit, the entropy ceiling for the binary secret. The integrated receipt prototype tests the conservative fallback at 0 and 0.5 bit.

**Algorithm 1. Integrity-aware reservation and commit**

~~~text
Inputs: recipient scope, candidate, current budget
1  Acquire the shared decision lock.
2  Read the trusted watermark, receipt cache, and pending reservations.
3  Check coverage of the committed receipt prefix.
4  If the prefix is incomplete or the watermark is invalid:
5      Select a verified authorized business-only variant, if available.
6  Otherwise:
7      Reconstruct the history used for this decision.
8      Enumerate the registered alternatives for the public slot.
9      Estimate the maximum cumulative entropy reduction.
10     If estimation succeeds and the envelope fits the budget:
11         Select the full currently authorized variant.
12     Otherwise select a verified business-only variant, if available.
13 If a variant was selected, record its pending reservation.
14 Release the decision lock.
15 If no variant was reserved, withhold the release.
16 Reacquire the shared lock and check that the reservation is still pending.
17 Commit through the trusted source, record the receipt, and clear the reservation.
18 Release the lock.
~~~

### D. Conditional Budget Property

**Proposition 1.** Suppose the gateway knows the true history visible at revocation, subsequent observations follow the order evaluated by the gate, and the gate uses a sound risk bound on every possible recipient-visible outcome. Suppose each fallback observation is conditionally independent of the secret given the true preceding prefix. Then every modeled visible prefix satisfies $R_t\le\varepsilon$.

**Proof.** At revocation, the additional entropy reduction is zero. If the next observation comes from a full release, the sound bound places it within the configured budget. If it comes from a fallback, conditional independence preserves the preceding posterior and hence its cumulative entropy reduction. An observable decision or indication of withholding must be accounted for as part of the observation. Induction over the ordered visible deliveries proves the result.

For a posterior that is uniform on two values at revocation, $H(p_t)=h_2(q_t)$. At $0\le\varepsilon\le1$ the invariant implies $q_t\le h_2^{-1}(1-\varepsilon)$ on the decreasing branch, so zero additional bits preserve the 50% prior guessing probability. The classifier scores are evaluated empirically against the exact reference. For arbitrary out-of-order delivery, evaluating all pending releases together need not bound every visible subset because realized Shannon entropy reduction can decrease when contradictory evidence arrives. The concurrency experiment establishes the outcome of the tested race in the local prototype.
