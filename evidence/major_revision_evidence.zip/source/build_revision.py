"""Assemble the English revision from frozen experimental records."""

from collections import Counter
from hashlib import sha256
from math import comb
from pathlib import Path
from random import Random
import json
import re
from shutil import copy2
from statistics import quantiles
from zipfile import ZIP_DEFLATED, ZipFile

from live_revision import HERE, ROOT, RUN, SOURCE, expected_codes, json_output, read, verify_seal


OUT = ROOT / 'outputs' / 'IEEE_Access_Revision'
MANUSCRIPT = OUT / 'IEEE_Access_Manuscript_EN_Revision_Draft.md'
ARCHIVE = OUT / 'revision_evidence.zip'


ABSTRACT = """Recipients retain information delivered before authorization is revoked. Later messages from other agents can combine with that information to expose a revoked secret. We present a gateway for workflows with registered evidence fields. It combines recipient-visible deliveries in a shared entropy budget, generalizes the clue portion of messages when necessary, and checks whether receipts cover a trusted delivery watermark. Detectable gaps trigger delivery of verified business fields alone. On paired replays of 200 synthetic Luna workflows across four domains, the history check reduced workflows with an above-budget release from 43/200 to 0/200 at a zero-bit budget. Relative to fixed field generalization at the same 50% Bayesian reconstruction probability, the gate increased required-field satisfaction from 50% to 61%, with a paired 95% confidence interval of 7.5 to 15.0 percentage points for the difference. We separately compare evidence estimators on frozen paraphrases, test coordinator task execution in fresh sessions, and examine sensitivity to incorrect signal reliability. Gains in evidence coverage depend on the registered vocabulary. Held-out free wording and a silently stale watermark identify conditions beyond the demonstrated protection."""


def splice(text, start, end, fragment):
    left, right = text.index(start), text.index(end, text.index(start) + 1)
    return text[:left] + fragment.strip() + '\n\n' + text[right:]


def paired_delta(details, left, right, cases, draws=2000):
    a, b = details[left], details[right]
    assert a.keys() == b.keys()
    per_domain = {}
    for key in sorted(a):
        per_domain.setdefault(cases[key]['domain'], []).append(int(b[key]['fields_correct']) - int(a[key]['fields_correct']))
    n = len(a)
    increments = [x for per in per_domain.values() for x in per]
    rng = Random(50713)
    samples = [sum(sum(rng.choices(v, k=len(v))) for v in per_domain.values()) / n for _ in range(draws)]
    low, high = quantiles(samples, n=40, method='inclusive')[0::38]
    win, loss = increments.count(1), increments.count(-1)
    discordant = win + loss
    p = min(1, 2 * sum(comb(discordant, k) for k in range(min(win, loss) + 1)) / 2**discordant)
    return {'n': n, 'estimate': sum(increments) / n, 'lo': low, 'hi': high, 'p_exact': p,
            'improved': win, 'worse': loss, 'resamples': draws}


def protocol_section():
    return """### D. Revision experiments

**Evidence estimation.** We evaluate newly frozen paraphrases and matched gateway replays across the four application domains. The prior 24 Luna rewrites are a separate regression set. The new set tests canonical renderings, certified aliases, unsupported terminology, and nonassertive contexts. We compare the original lexical model, a local clause-level relation parser, and a lexical control that receives the same alias normalization. We measure coverage, incorrect acceptance, and local latency on the same items. The gateway replays independently score the exact candidate envelope, realized prefix overshoot, and retained business fields.

 **Coordinator context and actual execution.** We first sample 24 prior cases, taking three originally empty and three originally correct answers per domain. Both conditions receive the exact same archived authorized receipts and task prompt. The fresh condition has no planning turn. In the planning-history condition, a new session executes the original planning protocol before answering. The original ephemeral sessions had already ended, so the planning condition is a matched recreation. This balanced diagnostic sample answers a context question and is not used to estimate the overall empty-answer rate. After inspecting early model replies, we add a separately registered prompt-only follow-up on the same cases. It uses independent fresh sessions, the same receipt payload and array format, and explicit instructions to extract the authorized identifiers.

For the execution comparison we freeze 80 cases, 20 per domain, with sampling proportionally stratified by evidence family and history condition within each domain. The same case is evaluated once per policy, each time in a newly opened coordinator session. The prompt contains that policy's delivered messages as business evidence and prohibits tool use. Exact identifiers must be grounded in the delivered input. Where the task requires precision, the specified role must have furnished the exact field and the model must return it. A withheld field can yield a correct abstention while leaving the overall task incomplete. The experiment records parse validity, explicit empty outputs, identifier correctness, full task correctness, and field availability.

**Blind observer and reliability.** On the frozen 80 cases, we form anonymous recipient views for explicit labels, the local-history shared zero-bit gate, and the integrity-aware shared zero-bit gate. Each condition is evaluated by two independent Astra sessions on disjoint 40-case decks. Each row lists the messages, public task question, and applicable reliability hint for its case. The observer is instructed to score each row independently and to guess zero on a tie or when it sees no directional evidence. We report both exact guesses and exact guesses for which Astra reports directional evidence. For the reliability analysis we hold the original 200 cases and the scorekeeper's generating reliability fixed. Only the reliability assumed by the online gate changes. The 80-case selection seed is 491563.

**Model execution metadata.** The recorded service identifiers are OpenAI gpt-6-luna for the coordinator and workers, and gpt-6.2-astra for the blind observer. The Luna runner requests low reasoning effort. The Astra sessions use high reasoning effort. The run logs record model identifiers, session and turn identifiers, token usage when available, and prompts. Provider-side snapshot identifiers and effective sampling temperature, top-p, and maximum generation length were not exposed in the retained records."""


def fault_table():
    fault = read(SOURCE / '账本故障与并发.json')
    labels = [('Complete receipts', 'complete'), ('One missing receipt', 'missing_one'),
              ('Two missing receipts', 'missing_two'), ('Out-of-order receipts', 'out_of_order'),
              ('Delayed tail receipt', 'delayed_tail'), ('Duplicate receipt', 'duplicate'),
              ('Unavailable watermark', 'watermark_unavailable'), ('Silently stale watermark', 'silent_missing')]
    s = ['### B. Receipt faults and concurrent release', '',
         'In the 200-case integrated replay, an actual visible prefix exceeded the zero-bit budget in 43 cases with the local-history gate. '
         'The integrity-aware gate recorded zero such cases and retained all mandatory identifiers. Table II reports '
         'the separate fault-injection and reservation trials. The watermark identified a gap under each of the five '
         'detectable fault conditions. A silently stale watermark left the missing history undetectable.', '',
         '**TABLE II. Reconstructions and business delivery under receipt faults and concurrent checks**', '',
         '| Condition | Trials per arm | Control reconstructions | Integrity-aware reconstructions | Integrity-aware business completion |',
         '|---|---:|---:|---:|---:|']
    for label, key in labels:
        row = fault['summary'][key]
        local, check = row['local_only'], row['checked']
        n = check['trials']
        s.append(f'| {label} | {n} | {local["reconstructed"]}/{n} | {check["reconstructed"]}/{n} | {check["task_completed"]}/{n} |')
    race = fault['concurrency']
    n = len(race['cases'])
    s.append(f'| Two-thread reservation race | {n} | {race["independent_check_reconstructed"]}/{n} | '
             f'{race["atomic_reconstructed"]}/{n} | {race["task_completed"]}/{n} |')
    s += ['', 'The fault control uses local receipt state. The concurrent control instead evaluates both proposals against '
              'independent snapshots. The measured two-thread race uses the in-memory prototype.']
    return '\n'.join(s)


def observer_section(audit):
    astra = audit['astra']
    assert all(astra[arm]['observed'] == 80 for arm in ('label', 'online_0', 'robust_0'))
    report = """### C. Evidence-estimator and observer results

For the registered fields in the original experiment, the estimator trained on 180 cases and used 80 separate cases for temperature calibration. Its mean absolute error across 1,200 controlled prefixes was approximately $7.3\times 10^{-17}$ bit, at the floating-point rounding scale for this evidence mechanism. The data therefore show agreement in the registered model. Results on independent rewrites and on the newly frozen utterances are reported separately.

**TABLE III. Independent paraphrases, expanded Astra observer, and local overhead**

| Measure | Condition | Result |
|---|---|---|
| Prior equivalent Luna rewrites | Lexical estimator | 1 correct acceptance, 2 incorrect acceptances, 20 abstentions out of 23 |
| Prior equivalent Luna rewrites | Relation parser | 3 correct acceptances, 0 incorrect acceptances, 20 abstentions out of 23 |""".replace('\t', r'\t')
    for arm, name in (('label','Explicit labels'), ('online_0','Local-history shared gate, 0 bit'),
                      ('robust_0','Integrity-aware shared gate, 0 bit')):
        row=astra[arm]
        report += (f'\n| Astra on frozen 80-case sample | {name} | {row["correct"]}/80 correct; '
                   f'{row["correct_with_reported_evidence"]}/80 correct with reported evidence |')
    report = report.replace('correct; ','correct, ')
    report += """
| Local model-gate decision | Standard integrity-aware 0-bit replay | 0.0003 ms p50, 0.0197 ms p95 |
| Local model-gate decision | Integrated receipt gate, 0 bit | 0.0030 ms p50, 0.0159 ms p95 |
| Local receipt recovery | Tail receipt delayed by an injected 3 ms | 3.520 ms p50, 3.798 ms p95 |
| Additional remote inference | Local estimator and ledger | 0 remote calls, 0 remote tokens |

A correct fixed guess can occur without evidence. The 80-case estimate follows the frozen sampling plan and is reported independently of the earlier 23-case exploratory spot check. Local latency excludes network delivery and model execution. The original Luna workflow run used 1,600 model turns. These workflow-generation costs are separate from the gate.

The new evidence challenge has 96 informative utterances and 24 nonassertive controls. The utterances and 64 paired workflows were hashed before scoring. Direction labels are assigned by construction, and the registered aliases and synthetic challenge design come from the same study. The lexical and relation estimators are evaluated on identical inputs.

**TABLE IV. Acceptance coverage and false acceptance on the frozen evidence challenge**

| Estimator | Correct informative acceptance | Incorrect informative acceptance | Informative abstention | Nonassertive controls accepted | Classification p95 |
|---|---:|---:|---:|---:|---:|
| Original lexical | 24/96 | 0/96 | 72/96 | 0/24 | 0.391 ms |
| Lexical with the same aliases | 72/96 | 0/96 | 24/96 | 12/24 | 0.490 ms |
| Clause-level relation parser | 72/96 | 0/96 | 24/96 | 0/24 | 0.010 ms |

The alias inventory accounts for the additional informative coverage. All methods abstained on the 24 items with unsupported terminology. The same-alias comparison shows that clause-level parsing reduces acceptance of the frozen nonassertive controls while retaining the coverage of certified aliases. Incorrect evidence acceptance at classification time and above-budget gateway release are different outcomes.

**TABLE V. Paired gateway replay on the new affirmative evidence fixtures**

| Budget | Estimator | Exact release | Above-budget release | Prefix overshoot | All task fields satisfied | Gateway p95 |
|---|---|---:|---:|---:|---:|---:|
| 0 bit | Original lexical | 4/96 | 0/96 | 0/96 | 34/64 | 0.794 ms |
| 0 bit | Lexical with the same aliases | 12/96 | 0/96 | 0/96 | 38/64 | 1.205 ms |
| 0 bit | Relation parser | 12/96 | 0/96 | 0/96 | 38/64 | 0.028 ms |
| 0.5 bit | Original lexical | 8/96 | 0/96 | 0/96 | 36/64 | 0.973 ms |
| 0.5 bit | Lexical with the same aliases | 24/96 | 0/96 | 0/96 | 44/64 | 1.271 ms |
| 0.5 bit | Relation parser | 24/96 | 0/96 | 0/96 | 44/64 | 0.029 ms |

All variants preserved every mandatory identifier in the 64 workflows. The parser and lexical model with aliases produced identical release and utility decisions on these affirmative fixtures. The effect on nonassertive controls appears in Table IV. The parser still abstained on 20 of the 23 independent meaning-preserving rewrites, which limits the result to the registered vocabulary and tested sentence forms. Gateway timing covers a warmed, serial, in-process decision from risk computation through receipt construction."""
    return report


def coordinator_section(audit, cases):
    expected = {'static': 80, 'robust_0': 80, 'planning_reference': 24, 'fresh_reference': 24, 'explicit_reference': 24}
    assert all(audit['luna'][arm]['observed'] == n for arm, n in expected.items())
    primary = paired_delta(audit['luna_details'], 'static', 'robust_0', cases)
    context = paired_delta(audit['luna_details'], 'planning_reference', 'fresh_reference', cases)
    prompt = paired_delta(audit['luna_details'], 'fresh_reference', 'explicit_reference', cases)
    lines = ['### D. Coordinator replies and authorized task execution', '',
             'The original authorized-reference task produced 120 exact answers, 78 empty arrays, and two other mismatches. '
             'All 78 archived empty answers were valid JSON arrays, and every required identifier occurred in the '
             'delivered messages for those trials. The recorded failure therefore occurs at the answer stage. '
             'The raw outputs establish omission, while the internal reason for the model choosing an empty array remains unknown.', '',
             '**TABLE VI. New Luna trials with identical tasks across each pair**', '',
             '| Condition | Cases | Required task fields visible | All identifiers correct | Model completed all required fields | Empty output | Invalid format |',
             '|---|---:|---:|---:|---:|---:|---:|']
    for key,name in (('planning_reference','Recreated planning context'),
                     ('fresh_reference','Fresh session, identical authorized receipts and original prompt'),
                     ('explicit_reference','Fresh session, identical authorized receipts and explicit extraction prompt'),
                     ('static','Fresh fixed field generalization'),
                     ('robust_0','Fresh integrity-aware 0-bit gate')):
        x = audit['luna'][key]
        n = expected[key]
        lines.append(f'| {name} | {n} | {x["field_visibility"]}/{n} | {x["codes_correct"]}/{n} | '
                     f'{x["fields_correct"]}/{n} | {x["empty"]}/{n} | {n-x["format_ok"]}/{n} |')
    lines += ['', f'For the 24-case context check, the fresh-minus-planning difference in exact completion is '
                  f'{100*context["estimate"]:+.1f} percentage points (paired 95% interval '
                  f'{100*context["lo"]:+.1f} to {100*context["hi"]:+.1f}). '
                  'This comparison uses a deliberately balanced diagnostic sample drawn from original empty and correct cases, '
                  'and the historical planning turn is recreated in the service. '
                  f'Within fresh sessions using byte-identical receipts and the same answer format, explicit extraction instructions change '
                  f'completion by {100*prompt["estimate"]:+.1f} percentage points (paired 95% interval '
                  f'{100*prompt["lo"]:+.1f} to {100*prompt["hi"]:+.1f}). The prompt-only result is an exploratory follow-up on this diagnostic sample.', '',
              f'Under the fresh paired policy test, the integrity-aware gate changes actual full-task completion by '
              f'{100*primary["estimate"]:+.1f} percentage points relative to fixed field generalization (paired 95% interval '
              f'{100*primary["lo"]:+.1f} to {100*primary["hi"]:+.1f}). '
              f'The matched cases include {primary["improved"]} improvements and {primary["worse"]} regressions.']
    checks = {'policy': primary, 'context': context, 'prompt': prompt}
    fallback = {arm: audit['luna'][arm]['execution_surfaces'].get('isolated Codex model subagent', 0) for arm in expected}
    if sum(fallback.values()):
        nonzero = [f'{n} from {arm}' for arm, n in fallback.items() if n]
        lines += ['', f'After repeated workspace-routing timeouts, {sum(fallback.values())} trials used isolated Luna sessions '
                      'through the Codex subagent interface with the corresponding frozen task text '
                      f'({", ".join(nonzero)}). The execution surface differs for these trials.']
        for label, (left, right) in {'policy': ('static', 'robust_0'),
                                     'context': ('planning_reference', 'fresh_reference'),
                                     'prompt': ('fresh_reference', 'explicit_reference')}.items():
            a, b = (audit['luna_details'][arm] for arm in (left, right))
            subset = [cid for cid in a if a[cid]['execution_surface'] == b[cid]['execution_surface'] == 'Codex App Server']
            if subset and len(subset) < len(a):
                filtered = {left: {cid: a[cid] for cid in subset}, right: {cid: b[cid] for cid in subset}}
                result = paired_delta(filtered, left, right, cases)
                checks[label + '_single_surface'] = result
                lines.append(f'The {label} comparison using only the {len(subset)} pairs served by the App Server '
                             f'gives a paired difference of {100*result["estimate"]:+.1f} percentage points.')
    return '\n'.join(lines), checks


def original_reply_audit():
    cases = {item['id']: item for item in read(SOURCE / '正式200题种子.json')}
    records = [json.loads(line) for line in
               (SOURCE / '独立Luna会话.jsonl').read_text(encoding='utf-8').splitlines() if line]
    findings, rows = Counter(), []
    for record in records:
        task = record['task']
        actual = json_output(task['text'])
        expected = expected_codes(cases[record['id']])
        receipts = '\n'.join(m['message'] for m in task['received'])
        visible = all(code in receipts for code in expected)
        assert actual == task['codes'] and isinstance(actual, list)
        category = 'empty' if not actual else 'exact' if sorted(actual) == expected else 'other_mismatch'
        findings[category] += 1
        assert category != 'empty' or visible
        rows.append({'case': record['id'], 'category': category,
                     'all_expected_codes_visible': visible,
                     'same_planning_session': task['session_id'] == record['plan']['session_id'],
                     'missing_codes': sorted(set(expected) - set(actual)),
                     'additional_codes': sorted(set(actual) - set(expected))})
    assert findings == {'empty': 78, 'exact': 120, 'other_mismatch': 2}
    return {'summary': findings, 'rows': rows}


def assembly():
    verify_seal()
    audit = read(RUN / 'results.json')
    assert read(HERE / 'quant' / 'results.json')
    assert read(HERE / 'semantic' / 'alias_ablation_results.json')
    source = (SOURCE / 'IEEE_Access_Manuscript_EN.md').read_text(encoding='utf-8')
    text = splice(source, '## Abstract', '**Index Terms**', '## Abstract\n\n' + ABSTRACT)
    text = text.replace('Our contributions are a recipient-view formulation', 'Our contributions are a schema-registered recipient-view formulation')
    text = splice(text, '## II. Related Work', '## III. System', (HERE / 'related.md').read_text(encoding='utf-8'))
    methods = (HERE / 'methods.md').read_text(encoding='utf-8')
    methods = methods.replace('Section VI-E reports the lexical model, the relation parser, and a resource-matched check with shared alias information if available.',
                              'Section VI-C reports the lexical model, the relation parser, and a resource-matched check with shared alias information.')
    text = splice(text, '## IV. Integrity-Aware', '## V. Experimental Design', methods)
    text = splice(text, '## VI. Results', '### A. Privacy–Utility Trade-Off', protocol_section() + '\n\n## VI. Results')
    text = text.replace('Figure 1 shows', 'Figure 2 shows').replace('![Fig. 1.', '![Fig. 2.').replace('**Fig. 1.** The left panel', '**Fig. 2.** The left panel')
    text = text.replace('(预算曲线_Luna.png)', '(budget_sweep.png)')
    text = re.sub(r'In the separate authorized-reference evaluation,[^\n]+\n\n', '', text, count=1)
    cases = {z['id']: z for z in read(SOURCE / '正式200题种子.json')}
    exec_section, ci = coordinator_section(audit, cases)
    quant = (HERE / 'quant' / 'quant.md').read_text(encoding='utf-8')
    quant = ('### E. Balanced accuracy and sensitivity to reliability\n\n' +
             quant.replace('### Class-Balanced Reconstruction Accuracy', '#### Class-balanced reconstruction accuracy')
                  .replace('### Sensitivity to Soft-Evidence Reliability', '#### Sensitivity to soft-evidence reliability')
                  .replace('Table S1', 'Table VII').replace('TABLE S1.', 'TABLE VII.')
                  .replace('Table S2', 'Table VIII').replace('TABLE S2.', 'TABLE VIII.'))
    text = splice(text, '### B. Receipt Faults and Concurrent Release', '## VII. Discussion',
                  '\n\n'.join([fault_table(), observer_section(audit), exec_section, quant]))
    text = text.replace('The authored messages include natural-language text around the registered spans.',
                        'The authored messages include natural-language text around the registered spans. The new parser results '
                        'depend on the certified alias inventory. Its separate nonassertive-control improvement does not establish '
                        'a bound for unregistered wording.')
    text = text.replace('scores actual coordinator answers in an authorized reference condition.',
                        'scores actual coordinator answers in an authorized reference condition and in a fresh, paired policy comparison.')
    text = text.replace('Free-text classification errors and silently stale sequence information identify the conditions under which the current implementation must be strengthened.',
                        'Incorrectly assumed soft-evidence reliability, free-text classification errors, and silently stale sequence '
                        'information identify the limits of the demonstrated protection.')
    data = ('## Data and Code Availability\n\nThe local revision artifact contains the original experiment archive, frozen revision '
            'inputs and answers, case-level scores, the semantic ablation, the reliability sweep, and the scripts. '
            'It preserves the input manifests and model observations needed for offline verification. '
            '[Reproduction artifact](revision_evidence.zip)')
    text = splice(text, '## Data and Code Availability', '## Acknowledgment', data)
    text = text.replace('[\\[8\\]][codex]', '[\\[33\\]][codex]')
    source_note = '<!-- Manuscript draft. Complete author names, affiliations, correspondence, and disclosure details before formatting with the IEEE Access submission template. -->'
    text = text[:text.index('## References')].rstrip() + '\n\n' + (HERE / 'refs.md').read_text(encoding='utf-8').strip() + '\n\n' + source_note + '\n'
    # Keep manuscript hyperlinks to sources and its single artifact. Figures use English filenames.
    text = re.sub(r'(?<!\!)\s*\[(?:[^\]\n]+)\]\(([^)\n]*[\u3400-\u9fff][^)\n]*)\)(?:\s*·\s*)?',
                  '', text)
    text = text.replace('The unit of accounting is a recipient and workflow session.',
                        'The unit of accounting is the pair of recipient and workflow session.')
    return text, ci


def package(text, ci):
    candidates = {'baseline/original_experiment_archive.zip': SOURCE.with_suffix('.zip'),
                  'figures/architecture.png': OUT / 'architecture.png', 'figures/budget_sweep.png': OUT / 'budget_sweep.png'}
    for p in (HERE / 'semantic').glob('*'):
        if p.is_file():
            candidates['semantic/' + p.name] = p
    for p in (HERE / 'quant').glob('*'):
        if p.is_file():
            candidates['quant/' + p.name] = p
    for p in RUN.rglob('*.json'):
        if p.name != 'transport_failures.json':
            candidates['live/' + p.relative_to(RUN).as_posix()] = p
    for p in (RUN / 'fallback').glob('*.txt'):
        candidates['live/fallback/' + p.name] = p
    for name in ('architecture.py', 'build_revision.py', 'live_revision.py', 'fallback_collect.py', 'related.md', 'refs.md', 'methods.md'):
        candidates['source/' + name] = HERE / name
    for name in ('run_luna.py', 'corpus.py'):
        candidates['source/original_runtime/' + name] = HERE.parent / 'revocation_qif_advanced' / name
    verification = {name: sha256(path.read_bytes()).hexdigest() for name, path in candidates.items()}
    if not OUT.exists():
        raise RuntimeError('Generate the architecture figure first')
    stg = ARCHIVE.with_suffix('.zip.tmp')
    with ZipFile(stg, 'w', ZIP_DEFLATED) as z:
        for name,path in sorted(candidates.items()):
            z.write(path, name)
        z.writestr('live/paired_intervals.json', json.dumps(ci, ensure_ascii=False, indent=2))
        z.writestr('live/original_reply_audit.json', json.dumps(original_reply_audit(), ensure_ascii=False, indent=2))
        z.writestr('sha256.json', json.dumps(verification, indent=2))
        z.writestr('README.txt', 'The baseline archive preserves the prior frozen corpus and release replays. '
                   'The live directory preserves revision prompts, anonymous observer inputs and outputs, and scoring. '
                   'The semantic and quant directories preserve the additional controlled comparisons. '
                   'From the extracted archive root run python -B source/live_revision.py score to recompute the revision model scores without issuing new requests. '
                   'The semantic and quant folders store their raw fixtures and scripts. The original experiment archive provides the prior replay dependencies.\n')
    with ZipFile(stg) as z:
        assert z.testzip() is None
        for name,digest in verification.items():
            assert sha256(z.read(name)).hexdigest() == digest
    stg.replace(ARCHIVE)
    MANUSCRIPT.write_text(text, encoding='utf-8')
    print(f'{MANUSCRIPT.name}: {MANUSCRIPT.stat().st_size:,} bytes. {len(verification)} archive inputs verified.')


if __name__ == '__main__':
    copy2(SOURCE / '预算曲线_Luna.png', OUT / 'budget_sweep.png')
    package(*assembly())
