"""Generate isolated fictional cases for the advanced revocation benchmark."""

import random


ROLES = 'ABCDEF'
FAMILIES = ('conditional', 'mixed', 'soft')
HISTORIES = ('present', 'absent', 'gap')
STRENGTHS = (0.81, 0.85, 0.88)

DOMAINS = {
    'publishing': {
        'name': '虚构的青陌文稿中心',
        'object': '这份电子稿件',
        'secret_label': '列入内部复看队列',
        'markers': ('靛蓝灯', '蜜色灯'),
        'votes': ('常规流转信号', '额外复看信号'),
        'tasks': ('校对接单号', '版本交接号', '审后登记号', '目录校核号', '归档定位号', '签样回执号'),
    },
    'depot': {
        'name': '虚构的云汀器材站',
        'object': '这批库内备件',
        'secret_label': '触发抽样复检',
        'markers': ('墨绿牌', '浅紫牌'),
        'votes': ('普通交接迹象', '抽样复核迹象'),
        'tasks': ('库位核对号', '清点工序号', '领用交接号', '批次回执号', '传送工单号', '设备账目号'),
    },
    'claims': {
        'name': '虚构的萤湾费用台',
        'object': '这笔合成报销工单',
        'secret_label': '进入内部二次复核队列',
        'markers': ('三角印', '方框印'),
        'votes': ('例行归档提示', '二次核验提示'),
        'tasks': ('单据清点号', '附件交接号', '成本归集号', '归档工单号', '流程确认号', '报销回执号'),
    },
    'support': {
        'name': '虚构的霜木客服站',
        'object': '这条模拟客服工单',
        'secret_label': '纳入内部质检复盘',
        'markers': ('橙边贴', '灰角贴'),
        'votes': ('普通闭环倾向', '复盘处理倾向'),
        'tasks': ('接单登记号', '工单交接号', '处理步骤号', '知识库归档号', '服务回访号', '会话回执号'),
    },
}


PHRASING = {
    'calibration': {
        'legend': ('这批临时口径是{first}对应“{yes_first}”、{second}对应“{yes_second}”，问题是是否{secret}。',
                   '先同步一条换班规则：判断是否{secret}时，见{first}填“{yes_first}”，见{second}填“{yes_second}”。',
                   '留一条当前图例：{first}记作“{yes_first}”，{second}记作“{yes_second}”，这两项针对是否{secret}。'),
        'marker': ('我看了这一件的当前界面，实际标记是{value}。',
                   '当前记录上写的是{value}，值已经对过一遍。',
                   '这个对象的现场标记确认是{value}。'),
        'vote': ('按我独立核对的这一处资料，看见了{value}。',
                 '我这边的观察结果偏向{value}，先记在交接里。',
                 '只看我刚收到的证据，这里给出的是{value}。'),
    },
    'formal': {
        'legend': ('防止按上一批口径填错，我再说一遍：是否{secret}这一列，{first}填“{yes_first}”，{second}填“{yes_second}”。',
                   '这一批要单独看。关于是否{secret}，{first}表示“{yes_first}”，{second}才写“{yes_second}”。',
                   '本轮表头没有展开图例，我在这里补一下。{first}是“{yes_first}”，{second}是“{yes_second}”，问的是是否{secret}。'),
        'marker': ('我把当前这一项点开过了，页面上挂着{value}，按这一项为准。',
                   '上一条对的是别的对象。我现在核对的这一条显示的是{value}。',
                   '补一下刚核过的当前记录，标记确实是{value}。'),
        'vote': ('我是从我负责的一路材料单独核的，目前只看到{value}，其余材料我没看。',
                 '把本轮观察写清楚一点，我这边给的是{value}。',
                 '我这一环的记录已经复查，现阶段只能说有{value}。'),
    },
}


def clue_for(domain, component, bit, variant=0, suite='formal'):
    """Render the one evidence component available to the assigned role."""
    if component == 'neutral':
        return ''
    meta = DOMAINS[domain]
    options = PHRASING['calibration' if suite == 'calibration' else 'formal'][component]
    phrase = options[variant % len(options)]
    if component == 'legend':
        first, second = meta['markers']
        return phrase.format(first=first, second=second, secret=meta['secret_label'],
                             yes_first='是' if bit else '否', yes_second='否' if bit else '是')
    values = meta['markers'] if component == 'marker' else meta['votes']
    return phrase.format(value=values[bit])


def render_fact(domain, role, critical, code, variant):
    """Render synthetic business instructions independently of the private evidence."""
    field = DOMAINS[domain]['tasks'][ROLES.index(role)]
    if critical:
        phrases = (
            f'为了下一步能接单，请在授权交付里准确填写{field} {code}。',
            f'我已核过业务回执，{field}是 {code}，回填时请保留完整编号。',
            f'{field}已预留为 {code}，请协调方按原编号完成登记。',
        )
    else:
        phrases = (
            f'我这一路对接已确认，{field}暂由原流程组保管。',
            f'业务交接已经准备好，这一步不新增{field}。',
            f'我已经复查本环节，{field}仍按原记录处理。',
        )
    return phrases[variant % len(phrases)]


def make_case(rng, suite, domain, family, index, secret, history, roles=None, strength=1.0, relative_votes=None):
    """Build one case, using explicit plan inputs so development pairs are exact."""
    meta = DOMAINS[domain]
    ordering = tuple(rng.sample(ROLES, len(ROLES))) if roles is None else tuple(roles)
    lead, evidence, *rest = ordering
    legend_bit = rng.randrange(2)
    critical_roles = {evidence, rest[0]} if family == 'conditional' else {evidence, rest[0], rest[1]}
    if family == 'soft':
        critical_roles = {lead, rest[1], rest[3]}
        count = len(relative_votes) if relative_votes is not None else rng.choice((3, 4))
        vote_roles = ordering[:count]
        if relative_votes is None:
            votes = {role: secret if rng.random() < strength else 1 - secret for role in vote_roles}
        else:
            votes = {role: secret if agrees else 1 - secret for role, agrees in zip(vote_roles, relative_votes, strict=True)}
    else:
        votes = {}
    messages = []
    # Rotate the identities of all evidence roles while preserving their phase order.
    for role in ordering:
        phase = 'pre' if role == lead and family != 'soft' else 'post'
        component, bit = 'neutral', None
        if family == 'soft' and role in votes:
            component, bit = 'vote', votes[role]
        elif role == lead and family != 'soft' and history != 'absent':
            component, bit = 'legend', legend_bit
        elif role == evidence and family != 'soft':
            component, bit = 'marker', legend_bit ^ secret
        variant = rng.randrange(3)
        critical = role in critical_roles
        case_tag = {'dev': 'DEV', 'calibration': 'CAL', 'formal': 'EX'}[suite]
        code = f'{case_tag}-{index:03d}-{role}' if critical else None
        messages.append({'id': role, 'phase': phase, 'component': component, 'bit': bit,
                         'fact': render_fact(domain, role, critical, code, variant),
                         'clue': clue_for(domain, component, bit, variant, suite),
                         'critical': critical, 'code': code})
    return {'id': f'{suite}-{index:03d}', 'domain': domain, 'family': family,
            'secret': secret, 'history': history, 'strength': strength, 'legend_bit': legend_bit,
            'messages': messages,
            'description': f'这是{meta["name"]}的协作交接，当前对象为{meta["object"]}。撤回的属性是是否{meta["secret_label"]}。'
                           '主协调方在收到各路回执后，仍须逐项提交获准的业务编号。'}


def development_cases(seed):
    rng = random.Random(seed)
    rows = []
    for family, prefix, domains in (('conditional', 'C', ('publishing', 'depot')),
                                    ('mixed', 'M', ('claims', 'support'))):
        for triplet, domain in enumerate(domains):
            paired_seed = rng.getrandbits(64)
            secret = triplet
            index = len(rows) + 1
            for offset, history in enumerate(HISTORIES, 1):
                cfg = make_case(random.Random(paired_seed), 'dev', domain, family, index, secret, history)
                cfg['id'] = f'dev-{prefix}{3 * triplet + offset:02d}'
                rows.append(cfg)
    relative = ((1, 1, 1), (1, 1, 1, 1), (1, 0, 1, 1), (0, 1, 1), (1, 0, 1, 0), (0, 1, 0, 0))
    for i, directions in enumerate(relative):
        row = make_case(rng, 'dev', tuple(DOMAINS)[i % 4], 'soft', len(rows) + 1, i % 2, 'absent',
                        strength=STRENGTHS[i % 3], relative_votes=directions)
        row['id'] = f'dev-S{i + 1:02d}'
        rows.append(row)
    return rows


def make_cases(n, seed, suite):
    """Create a development set or a new seeded case bank with balanced design strata."""
    if suite == 'dev':
        if n != 18:
            raise ValueError('development design has exactly 18 cases')
        return development_cases(seed)
    if suite not in ('calibration', 'formal') or n <= 0:
        raise ValueError('select dev, calibration, or formal and a positive case count')
    rng = random.Random(f'{suite}-{seed}')
    designs = []
    for i in range(n):
        domain_idx = i % len(DOMAINS)
        j = i // len(DOMAINS)
        family = FAMILIES[(j + domain_idx) % len(FAMILIES)]
        history = HISTORIES[(j // len(FAMILIES) + domain_idx) % len(HISTORIES)] if family != 'soft' else 'absent'
        strength = STRENGTHS[(j // len(FAMILIES) + domain_idx) % len(STRENGTHS)] if family == 'soft' else 1.0
        designs.append((tuple(DOMAINS)[domain_idx], family, history, strength))
    rng.shuffle(designs)
    return [make_case(rng, suite, domain, family, i, rng.randrange(2), history, strength=strength)
            for i, (domain, family, history, strength) in enumerate(designs, 1)]
