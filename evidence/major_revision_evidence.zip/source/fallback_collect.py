"""Use isolated Luna subagent outputs when the signed-in runner is unavailable."""

from collections import Counter

from live_revision import RUN, dump, registered_jobs, valid_answer, verify_seal


DIRECT = RUN / 'fallback'


def stable_agent_label(job):
    prefix = 'revision_luna_prompt' if job['arm'] == 'explicit_reference' else 'revision_luna_fallback'
    return f'/root/{prefix}_{job["case"][-3:]}'


def collect():
    verify_seal()
    DIRECT.mkdir(exist_ok=True)
    adopted = Counter()
    for job in registered_jobs():
        jid = job['id']
        target = RUN / 'answers' / (jid + '.json')
        if target.is_file() or job['arm'] == 'planning_reference':
            continue
        if job['arm'] == 'explicit_reference':
            (DIRECT / (jid + '.txt')).write_text(job['prompt'], encoding='utf-8')
        source = DIRECT / (jid + '_answer.txt')
        if not source.is_file():
            continue
        response = {'text': source.read_text(encoding='utf-8-sig'), 'model': 'gpt-6-luna',
                    'session_id': 'collaboration:' + stable_agent_label(job), 'turn_id': None,
                    'usage': None, 'execution_surface': 'isolated Codex model subagent'}
        dump(target, {'job': jid, 'response': response, 'planning': None, 'score': valid_answer(response, job)})
        adopted[job['arm']] += 1
    print(dict(adopted))


if __name__ == '__main__':
    collect()
