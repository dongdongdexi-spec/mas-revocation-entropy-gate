"""Freeze new synthetic renderings and matched gateway workflows."""

import json
from hashlib import sha256
from pathlib import Path
from random import Random
import sys

from collections import Counter


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1] / 'revocation_qif_advanced'))
from corpus import DOMAINS


# Public aliases, registered by the application. None includes a case-specific secret.
REGISTERED = {
    'publishing': (('深蓝色指示灯', '金黄色提示灯'), ('常规流转线索', '加一道复看倾向')),
    'depot': (('墨绿色挂牌', '淡紫色挂牌'), ('照常交接征象', '追加抽样信号')),
    'claims': (('三角形盖印', '四边框盖印'), ('正常入档倾向', '追加核验倾向')),
    'support': (('橘色边签', '灰色角签'), ('按常规结单的指示', '另安排复盘的指示')),
}
OUTSIDE_REGISTRY = (
    ('预先登记列表里排在前位的那枚标识', '预先登记列表里排在后位的那枚标识'),
    ('预先登记序位前一档的方向', '预先登记序位后一档的方向'),
)


def phrase(domain, component, bit, style):
    registry = DOMAINS[domain]
    if style == 0:
        markers, votes = registry['markers'], registry['votes']
    elif style in (1, 2):
        markers, votes = REGISTERED[domain]
    else:
        markers, votes = OUTSIDE_REGISTRY
    if component == 'legend':
        a, b = markers
        values = ('归为否', '归为是') if bit == 0 else ('归为是', '归为否')
        positive, negative = (b, a) if bit == 0 else (a, b)
        r = registry['secret_label']
        styles = (
            f'对本组的{r}请采用新图例。{a}应判为{values[0][-1]}；{b}应判为{values[1][-1]}。',
            f'这批的解释写在交班板上：{a}{values[0]}，{b}{values[1]}。',
            f'用于本案的两种标记按此解释。{positive}对应肯定；{negative}对应否定。',
            f'规则仅对这一批适用：{a}{values[0]}；{b}{values[1]}。',
        )
    elif component == 'marker':
        value = markers[bit]
        styles = (
            f'我核验过目标页；该对象实际亮出的标识为{value}，已抄进交接记录。',
            f'这件的电子交接条上，实拍所见是{value}；所见只针对现在这件。',
            f'{value}确实出现在本件的系统读数里，旧稿的图样先不管。',
            f'本项实地看到的是{value}。交接时只转这个标记。',
        )
    else:
        value = votes[bit]
        styles = (
            f'独立看完我这一环节，现在确认留下一条{value}。',
            f'先按我这路实测记录交班。这一轮出现{value}，仅代表本路观察。',
            f'{value}是我这次核验得到的方向，其余渠道仍未知。',
            f'本次收到的是{value}，这里只转述我自己的观察方向。',
        )
    text = styles[style]
    return f'{registry["name"]}交班。{text}' if style == 3 else text


def nonassertive(domain):
    ((marker, other), (vote, alternate)) = REGISTERED[domain]
    standard, standard_other = DOMAINS[domain]['markers']
    return (
        f'联调例子里可写{marker}。实际对象还未检查。',
        f'看到{other}只是旧件照片的内容，当前对象没有给出标识。',
        f'本次只是讨论{vote}这种写法，状态还未判定。',
        f'目前{alternate}尚未证实，仅存为一个备选判断。',
        f'假若现场出现{standard}才使用这条交接规则；本案没有观测结果。',
        f'有一条传闻说本件是{standard_other}，还未复核，无可交付的断言。',
    )


def make_items():
    rows = []
    for domain in DOMAINS:
        for component in ('legend', 'marker', 'vote'):
            for bit in (0, 1):
                for style in range(4):
                    text = phrase(domain, component, bit, style)
                    rows.append({'id': f'{domain}-{component}-{bit}-{style}', 'domain': domain,
                                 'type': component, 'bit': bit, 'style': style, 'text': text})
        for i, text in enumerate(nonassertive(domain)):
            rows.append({'id': f'{domain}-unknown-{i}', 'domain': domain, 'type': 'unknown',
                         'bit': None, 'style': i, 'text': text})
    assert len(rows) == len({r['text'] for r in rows}) == 120
    return rows


def make_cases():
    rng = Random(416041)
    local_cases = []
    for domain in DOMAINS:
        for style in range(4):
            for history in ('absent', 'present', 'gap', 'soft'):
                truth = (list(DOMAINS).index(domain) + style) % 2
                strength = (0.81, 0.85, 0.88, 0.85)[style]
                head = rng.randrange(2)
                number = f'SP-{len(local_cases)+1:03d}'
                if history == 'soft':
                    # The observer model assumes independent Bernoulli evidence. Draw
                    # from that same mechanism rather than conditioning on correctness.
                    evidence = [('vote', truth if rng.random() < strength else 1 - truth) for _ in range(3)]
                else:
                    evidence = [('marker', truth ^ head)]
                local_cases.append({'id': number, 'domain': domain, 'style': style,
                                    'history': history, 'truth': truth, 'strength': strength,
                                    'pre': [f'{domain}-legend-{head}-{style}'] if history in ('present', 'gap') else [],
                                    'post': [{'clue': f'{domain}-{kind}-{bit}-{style}',
                                              'business_code': f'{number}-{step+1}',
                                              'precision_required': step == 0 and domain in ('depot', 'claims')}
                                             for step, (kind, bit) in enumerate(evidence)]})
    assert len(local_cases) == 64 and Counter(row['domain'] for row in local_cases).most_common()[-1][1] == 16
    return local_cases


def dump(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


if __name__ == '__main__':
    plaintext = make_items()
    dump(HERE / 'heldout_messages.json', plaintext)
    dump(HERE / 'heldout_cases.json', make_cases())
    names = ('fixture.py', 'heldout_messages.json', 'heldout_cases.json')
    dump(HERE / 'freeze.json', {
        'files': {name: sha256((HERE / name).read_bytes()).hexdigest() for name in names},
        'scope': 'Synthetic surface renderings, with a preregistered alias inventory, fresh structures, and an explicit unsupported terminology stratum.',
        'policy_budgets': [0, .5],
    })
