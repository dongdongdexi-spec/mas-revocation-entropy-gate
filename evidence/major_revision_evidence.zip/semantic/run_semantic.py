"""Evaluate a local semantic relation parser on frozen synthetic paraphrases."""

from collections import Counter
from hashlib import sha256
import json
import re
from statistics import median, quantiles
from time import perf_counter_ns

from fixture import DOMAINS, HERE, REGISTERED, dump
from corpus import make_cases
from estimator import compose_posterior, entropy, fit, normalize
from replay import evaluation_rows, oracle_posterior


UNKNOWN = ('unknown', .5, 0.)
CLAUSE = re.compile(r'[，,。；;、！？：:\r\n]+')
GUARDED = re.compile(r'假若|若是|如果|尚无|还未|尚未|待查|未证实|未核实|请查找|'
                     r'举例|例子|作为示例|转述|只引用|并未|并非|不是|未呈现|旧件照片|'
                     r'只是讨论|两可|可能|草案|备选|传闻|不应当认作|没有给出')
ASSERTION = re.compile(r'确实|已经|实际|实测|实拍|现场|本次|本件|本轮|'
                      r'这一轮|这一件|这件|此件|目标|交接记录|系统读数|我核对|'
                      r'文件记录|现在确认|得到|本路|目前只看到|现阶段|偏向|'
                      r'我看到|我这轮|这次|收到|观察到|本项')
RELATION = re.compile(r'^(?:就是|对应|归为|应判为|判为|表示|代表|为|作|是|'
                      r'才写|填|写|记作)[“"「『]?'
                      r'(否定|不纳入|不触发|不做|不进入|不会进|不进|否|'
                      r'肯定|要做|纳入|触发|进入|会进|是|进)')
NEGATIVE = frozenset(('否定', '不纳入', '不触发', '不做', '不进入', '不会进', '不进', '否'))


class RelationParser:
    """Resolve certified aliases and interpret directional assertions by clause."""

    def __init__(self):
        self.lexicons = {}
        for domain, meta in DOMAINS.items():
            aliases = {normalize(token): (kind, bit)
                       for bundle in ((meta['markers'], meta['votes']), REGISTERED[domain])
                       for kind, terms in zip(('marker', 'vote'), bundle, strict=True)
                       for bit, token in enumerate(terms)}
            self.lexicons[domain] = aliases, re.compile(
                '|'.join(map(re.escape, sorted(aliases, key=len, reverse=True))))

    def classify(self, domain, text):
        aliases, pattern = self.lexicons[domain]
        relations = {}
        assertions = set()
        for clause in CLAUSE.split(normalize(text)):
            hits = list(pattern.finditer(clause))
            if not hits or GUARDED.search(clause):
                continue
            for i, hit in enumerate(hits):
                component, bit = aliases[hit.group()]
                end = hits[i+1].start() if i+1 < len(hits) else len(clause)
                relation = RELATION.match(clause[hit.end():end]) if component == 'marker' else None
                if relation:
                    polarity = int(relation[1] not in NEGATIVE)
                    if bit in relations and relations[bit] != polarity:
                        return UNKNOWN
                    relations[bit] = polarity
                elif ASSERTION.search(clause):
                    assertions.add((component, bit))
        if set(relations) == {0, 1} and relations[0] != relations[1] and not assertions:
            return 'legend', float(relations[0]), 1.
        if not relations and len(assertions) == 1:
            kind, bit = next(iter(assertions))
            return kind, float(bit), 1.
        return UNKNOWN


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def elapsed(start):
    return (perf_counter_ns() - start) / 1e6


def timing(times):
    return {'p50_ms': median(times), 'p95_ms': quantiles(times, n=100, method='inclusive')[94]}


def outcome(row, prediction):
    kind, probability, _ = prediction
    if kind == 'unknown':
        return 'abstained' if row['type'] != 'unknown' else 'correct_abstention'
    if (kind, int(probability > .5)) == (row['type'], row['bit']):
        return 'correct_accept'
    return 'wrong_accept'


def audit_messages(items, classify):
    details = []
    for row in items:
        timestamp = perf_counter_ns()
        predicted = classify(row['domain'], row['text'])
        duration = elapsed(timestamp)
        details.append({'id': row['id'], 'type': row['type'], 'style': row['style'],
                        'equivalent': row.get('equivalent', True),
                        'outcome': outcome(row, predicted), 'predicted_type': predicted[0],
                        'p1': predicted[1], 'time_ms': duration})
    informative = [r for r in details if r['type'] != 'unknown' and r['equivalent']]
    summary = {'items': len(details), 'equivalent_informative': len(informative),
               'informative_outcomes': dict(Counter(r['outcome'] for r in informative)),
               'negative_control_outcomes': dict(Counter(r['outcome'] for r in details if r['type'] == 'unknown')),
               'non_equivalent_outcomes': dict(Counter(r['outcome'] for r in details if not r['equivalent'])),
               **timing([r['time_ms'] for r in details])}
    return {'summary': summary, 'rows': details}


def estimated_risk(predictions, strength):
    samples = [(p[0], p[1], strength) for p in predictions]
    if any(p[0] == 'unknown' for p in samples):
        return None
    return 1.0 - entropy(compose_posterior(samples))


def true_risk(history, strength):
    known = [{'component': item['type'], 'bit': item['bit']} for item in history]
    return 1.0 - entropy(oracle_posterior(known, strength))


def replay(cases, frozen_items, classify, budget):
    index = {r['id']: r for r in frozen_items}
    details = []
    durations = []
    for row in cases:
        true_history = [index[message] for message in row['pre']]
        # Detected gaps always use a business-only version for these budgets.
        gateway_history = [] if row['history'] == 'gap' else true_history.copy()
        cached = {}

        def decode(item):
            key = item['id']
            if key not in cached:
                cached[key] = classify(item['domain'], item['text'])
            return cached[key]

        outputs = []
        for post in row['post']:
            actual = index[post['clue']]
            two_values = [index[f"{actual['domain']}-{actual['type']}-{b}-{actual['style']}"] for b in (0, 1)]
            timestamp = perf_counter_ns()
            if row['history'] == 'gap':
                estimated = None
                allow = False
            else:
                estimates = [estimated_risk([*(decode(x) for x in gateway_history), decode(option)], row['strength'])
                             for option in two_values]
                estimated = None if None in estimates else max(estimates)
                allow = estimated is not None and estimated <= budget + 1.e-10
            delivered = f"业务编号：{post['business_code']}。"
            if allow:
                delivered += actual['text']
            duration = elapsed(timestamp)
            durations.append(duration)
            actual_upper = max(true_risk([*true_history, option], row['strength']) for option in two_values)
            if allow:
                true_history.append(actual)
                gateway_history.append(actual)
            actual_visible = true_risk(true_history, row['strength'])
            outputs.append({'decision': 'exact' if allow else 'coarse',
                            'estimated_upper_bit': estimated, 'oracle_upper_bit': actual_upper,
                            'actual_visible_reduction_bit': actual_visible,
                            'above_budget_release': allow and actual_upper > budget + 1.e-10,
                            'visible_overshoot': actual_visible > budget + 1.e-10,
                            'business_code_visible': post['business_code'] in delivered,
                            'precision_required': post['precision_required'], 'receipt': delivered,
                            'decision_ms': duration})
        details.append({'id': row['id'], 'domain': row['domain'], 'history': row['history'], 'style': row['style'],
                        'all_fields': all(r['business_code_visible'] and
                                          (not r['precision_required'] or r['decision'] == 'exact') for r in outputs),
                        'all_business_codes': all(r['business_code_visible'] for r in outputs),
                        'outcomes': outputs})
    transactions = [tx for row in details for tx in row['outcomes']]
    summary = {'cases': len(details), 'transactions': len(transactions),
               'exact_releases': sum(r['decision'] == 'exact' for r in transactions),
               'coarse_releases': sum(r['decision'] == 'coarse' for r in transactions),
               'above_budget_releases': sum(r['above_budget_release'] for r in transactions),
               'visible_overshoots': sum(r['visible_overshoot'] for r in transactions),
               'all_task_fields_satisfied': sum(r['all_fields'] for r in details),
               'all_business_codes_retained': sum(r['all_business_codes'] for r in details), **timing(durations)}
    return {'summary': summary, 'rows': details}


def load_legacy():
    prior = HERE.parents[1] / 'revocation_qif_advanced'
    truth = {x['id']: x for x in read(prior / '新措辞真值.json')}
    revisions = {x['id']: x for x in read(prior / '新措辞输出.json')}
    ratings = {x['id']: x for x in read(prior / '新措辞核验.json')}
    print('legacy keys:', sorted(next(iter(truth.values()))), sorted(next(iter(ratings.values()))))
    details = []
    for i, row in truth.items():
        details.append({'id': i, 'domain': row['domain'], 'type': row['component'],
                        'bit': row['bit'], 'style': -1, 'text': revisions[i]['text'],
                        'equivalent': ratings[i]['equivalent']})
    return details


def main():
    freeze = read(HERE / 'freeze.json')
    for name, expected in freeze['files'].items():
        assert sha256((HERE / name).read_bytes()).hexdigest() == expected, f'locked fixture changed: {name}'
    items = read(HERE / 'heldout_messages.json')
    cases = read(HERE / 'heldout_cases.json')
    legacy = load_legacy()
    # The original estimator is retrained with its original fit and calibration
    # cohorts. Neither new benchmark input nor legacy rewrite data is fitted.
    baseline = fit(evaluation_rows(make_cases(180, 12031, 'calibration')),
                   evaluation_rows(make_cases(80, 46733, 'calibration')))
    parser = RelationParser()
    estimators = {'lexical': lambda domain, text: baseline.classify.__wrapped__(baseline, text),
                  'relation_parser': parser.classify}
    results = {'freeze': freeze, 'first_pass_protocol': {
        'case_level_seed': 416041,
        'separate_old_rewrite_regression': True,
        'baseline_retrained_with_original_cohorts': [12031, 46733],
        'latency': 'same-host, warmed-process serial perf_counter_ns; classifiers continuously uncached at item level; local per-workflow cache in both replay arms',
    }}
    for name, estimate in estimators.items():
        estimate(items[0]['domain'], items[0]['text'])
        results[name] = {'heldout_messages': audit_messages(items, estimate),
                         'legacy_24': audit_messages(legacy, estimate),
                         'replay': {str(epsilon): replay(cases, items, estimate, epsilon)
                                    for epsilon in freeze['policy_budgets']}}
    original = results['lexical']['legacy_24']['summary']['informative_outcomes']
    assert original == {'correct_accept': 1, 'wrong_accept': 2, 'abstained': 20}, original
    for v in estimators:
        assert all(a['summary']['all_business_codes_retained'] == 64 for a in results[v]['replay'].values())
    dump(HERE / 'results.json', results)
    for name in estimators:
        record = results[name]
        print(name, 'heldout:', record['heldout_messages']['summary'])
        print(name, 'legacy:', record['legacy_24']['summary'])
        print(name, 'replay:', {k: v['summary'] for k,v in record['replay'].items()})


if __name__ == '__main__':
    main()
