"""Give the original lexical classifier the relation parser's alias registry."""

from hashlib import sha256
import re

from fixture import DOMAINS, HERE, REGISTERED, dump
from corpus import make_cases
from estimator import fit, normalize
from replay import evaluation_rows
from run_semantic import audit_messages, load_legacy, read, replay


def compile_normalizers():
    normalizers = {}
    for domain, registration in REGISTERED.items():
        canonical = (DOMAINS[domain]['markers'], DOMAINS[domain]['votes'])
        mapping = {normalize(alias): normalize(name)
                   for aliases, names in zip(registration, canonical, strict=True)
                   for alias, name in zip(aliases, names, strict=True)}
        pattern = re.compile('|'.join(map(re.escape, sorted(mapping, key=len, reverse=True))))
        normalizers[domain] = pattern, mapping
    return normalizers


def main():
    freeze = read(HERE / 'freeze.json')
    for name, expected in freeze['files'].items():
        assert sha256((HERE / name).read_bytes()).hexdigest() == expected, f'locked fixture changed: {name}'
    cases = read(HERE / 'heldout_cases.json')
    items = read(HERE / 'heldout_messages.json')
    legacy = load_legacy()
    baseline = fit(evaluation_rows(make_cases(180, 12031, 'calibration')),
                   evaluation_rows(make_cases(80, 46733, 'calibration')))
    normalizers = compile_normalizers()

    def classify(domain, text):
        pattern, names = normalizers[domain]
        rewritten = pattern.sub(lambda match: names[match.group()], normalize(text))
        return baseline.classify.__wrapped__(baseline, rewritten)

    classify(items[0]['domain'], items[0]['text'])
    run = {'arm': 'lexical_with_same_registered_aliases',
           'freeze': freeze,
           'method': 'Same certified aliases as the parser. Normalize them to the original lexical anchors before applying the unchanged, calibrated original classifier. The original training and calibration cohorts are reused.',
           'heldout_messages': audit_messages(items, classify),
           'legacy_24': audit_messages(legacy, classify),
           'replay': {str(epsilon): replay(cases, items, classify, epsilon)
                      for epsilon in freeze['policy_budgets']}}
    assert all(report['summary']['all_business_codes_retained'] == 64
               for report in run['replay'].values())
    dump(HERE / 'alias_ablation_results.json', run)
    print('heldout:', run['heldout_messages']['summary'])
    print('legacy:', run['legacy_24']['summary'])
    print('replay:', {budget: v['summary'] for budget, v in run['replay'].items()})


if __name__ == '__main__':
    main()
