#### Resource-matched alias ablation

To isolate the effect of the public alias inventory, we normalized the same certified aliases to the original anchor strings and supplied the result to the original lexical estimator. Its training data, calibration set, temperature, thresholds, and abstention rules were unchanged. The ablation reused the frozen utterances and matched workflows. Latency includes the alias normalization step.

| Evidence estimator | Correctly accepted informative items | Incorrectly accepted informative items | Informative abstentions | Nonassertive controls accepted as evidence | Classification p95 |
|---|---:|---:|---:|---:|---:|
| Original lexical | 24/96 | 0/96 | 72/96 | 0/24 | 0.391 ms |
| Lexical with the same aliases | 72/96 | 0/96 | 24/96 | 12/24 | 0.490 ms |
| Clause-level relation parser | 72/96 | 0/96 | 24/96 | 0/24 | 0.010 ms |

The resource-matched lexical estimator and the parser accepted the same 72 informative utterances. The alias inventory therefore accounts for the improved informative-item coverage. Their behavior on nonassertive controls differed. The normalized lexical estimator accepted 12 controls as evidence, while the parser abstained on all 24. This comparison tests evidence classification. The workflow replay below reports above-budget gateway releases separately. On the 23 independently reviewed meaning-preserving Luna rewrites, the lexical estimator with alias normalization still correctly accepted 1, incorrectly accepted 2, and abstained on 20. The relation parser correctly accepted 3 and abstained on 20.

| Budget | Estimator | Exact releases | Above-budget releases | Visible prefix overshoots | All task fields satisfied | Gateway p95 |
|---|---|---:|---:|---:|---:|---:|
| 0 bit | Lexical with the same aliases | 12/96 | 0/96 | 0/96 | 38/64 | 1.205 ms |
| 0 bit | Clause-level relation parser | 12/96 | 0/96 | 0/96 | 38/64 | 0.028 ms |
| 0.5 bit | Lexical with the same aliases | 24/96 | 0/96 | 0/96 | 44/64 | 1.271 ms |
| 0.5 bit | Clause-level relation parser | 24/96 | 0/96 | 0/96 | 44/64 | 0.029 ms |

At both operating points all 64 workflows retained the mandatory business identifiers. The two estimators made identical workflow-level release and utility decisions under these matched fixtures. The parser’s supported advantages in this experiment are its lower local processing time and its treatment of the frozen nonassertive controls under the same alias inventory. The additional replay utility relative to the original lexical estimator was reproduced by alias normalization alone.
