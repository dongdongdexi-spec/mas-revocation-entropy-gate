### Lightweight Semantic Evidence Estimation

We compare the original character-based lexical estimator with a local, non-neural semantic relation parser. The parser normalizes certified domain aliases, separates clauses, resolves both arms of a legend relation, and extracts asserted marker or vote directions. It abstains on unsupported terms, conflicting directions, and registered terms used only in certain nonassertive constructions. A successful parse yields a typed evidence direction for the same posterior update used by the lexical estimator. The alias inventory is part of the application schema. The parser uses neither a pretrained encoder nor external inference.

The new challenge set contains 120 frozen synthetic Chinese utterances from the four application domains. The 96 informative utterances contain new canonical-anchor renderings, alias substitutions, clause reordering, and evidence terms outside the approved registry. The 24 negative controls mention familiar domain terms in hypotheticals, draft alternatives, or other nonassertive contexts. Direction labels are assigned by construction. The complete messages and 64 replay workflows were hashed before running the estimator comparison. The constructed renderings are distinct from the 24 independently reviewed Luna rewrites in the original regression set.

| Test set and estimator | Correctly accepted | Incorrectly accepted | Abstained | Classification p95 |
|---|---:|---:|---:|---:|
| New informative utterances, lexical | 24/96 | 0/96 | 72/96 | 0.391 ms |
| New informative utterances, relation parser | 72/96 | 0/96 | 24/96 | 0.010 ms |
| Prior meaning-preserving Luna rewrites, lexical | 1/23 | 2/23 | 20/23 | 0.388 ms |
| Prior meaning-preserving Luna rewrites, relation parser | 3/23 | 0/23 | 20/23 | 0.009 ms |

The new-set acceptance coverage rose from 25% to 75%. Both estimators classified the 24 new canonical-anchor renderings correctly. The difference came from the 48 constructions using registered aliases, while both estimators abstained on all 24 items that used unsupported terminology. Both also abstained on all 24 negative controls. The one non-equivalent item in the earlier 24-utterance regression set was rejected by both estimators. Classification p95 uses all utterances in the respective set, including controls or the non-equivalent item, with a warmed local process and no classification cache.

We then replayed 64 matched workflows, 16 per domain, comprising 96 post-revocation decisions at each operating point. For each public slot, the gate compared both evidence directions for that slot’s fixed rendering style. An estimator abstention or a detected history gap selected the business-only version. We independently checked the candidate envelope under the true generation mechanism for every exact release and recomputed entropy over the actual visible transcript after every decision. Thus, above-budget admissions and realized prefix overshoots are separate outcomes.

| Budget and estimator | Exact releases | Above-budget exact releases | Realized prefix overshoots | All task fields satisfied | Gateway p95 |
|---|---:|---:|---:|---:|---:|
| 0 bit, lexical | 4/96 | 0/96 | 0/96 | 34/64 | 0.794 ms |
| 0 bit, relation parser | 12/96 | 0/96 | 0/96 | 38/64 | 0.028 ms |
| 0.5 bit, lexical | 8/96 | 0/96 | 0/96 | 36/64 | 0.973 ms |
| 0.5 bit, relation parser | 24/96 | 0/96 | 0/96 | 44/64 | 0.029 ms |

All variants delivered every mandatory business identifier in 64/64 workflows. The task-field differences arise from precision-sensitive requirements in inventory and reimbursement. Gateway latency is a serial, in-process measurement from estimated-risk computation through construction of the permitted receipt, with the same per-workflow caching arrangement in both arms. It excludes transport and remote inference.

The improvement quantifies the behavior of a parser over synthetic, schema-registered evidence with held-out surface constructions. The aliases and benchmark were authored within the same study. In the prior externally generated paraphrases, the revised parser still abstained on 20 of 23 meaning-preserving items. This leaves broad natural-language inference and a reliable upper bound for unseen wording outside the demonstrated scope.
