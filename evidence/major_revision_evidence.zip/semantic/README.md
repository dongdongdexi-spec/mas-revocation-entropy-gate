# Semantic estimator pilot

Run `python -B -X utf8 work/ieee_revision/semantic/run_semantic.py` from the workspace root using the original experiment's Python dependencies. The runner verifies `freeze.json` before reading the 120-item utterance set and the 64 matched replay fixtures. The command also retrains the original lexical estimator from the original cohort seeds and checks the legacy paraphrase regression counts. Timings vary on rerun.

- `fixture.py` defines the synthetic phrases, authorized alias registry, held-out workflow generation, and freeze procedure.
- `heldout_messages.json` contains all 96 informative utterances and 24 negative controls.
- `heldout_cases.json` records matched delivery histories, truthful evidence labels and business requirements.
- `results.json` reports the estimated and exact oracle risks, delivered strings, task field preservation, classification decisions and local decision timing.
- `semantic.md` contains the English manuscript fragment and both result tables.

The scope is local synthetic schema mediation. Successful parses use registered aliases, directional relations and bounded assertion patterns. The gate can defer to the business-only variant when the parser abstains. The 24 earlier Luna rewrites serve as a separate regression set and remain the weaker open-language result.

The resource-matched ablation is in **alias_ablation.md** and **alias_ablation_results.json**. Run **run_alias_ablation.py** to normalize the parser's registered aliases to their canonical forms before applying the unchanged lexical classifier. The original files and all frozen fixture hashes are preserved.
