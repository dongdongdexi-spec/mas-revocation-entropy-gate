"""Recompute MAP balance and replay a gateway-only soft-reliability perturbation."""

import argparse
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[3]
OFFSETS = (-0.10, -0.05, 0.0, 0.05, 0.10)
BUDGETS = (('025', 0.25), ('05', 0.50))
POLICY_NAMES = {
    'label': 'Explicit labels', 'uniform': 'Uniform generalization',
    'static': 'Fixed field generalization', 'per_message': 'Per-message estimation',
    'exact': 'Exact reference, 0 bit', 'online_0': 'Local-history shared, 0 bit',
    'online_025': 'Local-history shared, 0.25 bit', 'online_05': 'Local-history shared, 0.5 bit',
    'online_1': 'Local-history shared, 1 bit', 'online_inf': 'Local-history shared, unlimited',
    'robust_0': 'Integrity-aware shared, 0 bit', 'robust_025': 'Integrity-aware shared, 0.25 bit',
    'robust_05': 'Integrity-aware shared, 0.5 bit', 'robust_1': 'Integrity-aware shared, 1 bit',
    'robust_inf': 'Integrity-aware shared, unlimited',
}


class GatewayReliability:
    """Change only the reliability consumed by the online estimator."""

    def __init__(self, model, rho_hat):
        self.model = model
        self.rho_hat = rho_hat

    def analyze(self, messages):
        return self.model.analyze([{**message, 'strength': self.rho_hat} for message in messages])


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def verify_inputs(artifact):
    hashes = load(artifact / '输入哈希.json')
    for filename, expected in hashes.items():
        got = sha256((artifact / filename).read_bytes()).hexdigest()
        assert got == expected, (filename, got, expected)
    return hashes


def confusion(rows):
    counts = Counter((r['truth'], r['curve'][-1]['map_prediction']) for r in rows)
    n00, n01, n10, n11 = (counts[0, 0], counts[0, 1], counts[1, 0], counts[1, 1])
    n0, n1 = n00 + n01, n10 + n11
    assert n0 > 0 and n1 > 0
    return {
        'cases': len(rows), 'n00': n00, 'n01': n01, 'n10': n10, 'n11': n11,
        'class_0_recall': n00 / n0, 'class_1_recall': n11 / n1,
        'accuracy': (n00 + n11) / len(rows),
        'balanced_accuracy': ((n00 / n0) + (n11 / n1)) / 2,
    }


def summarize(rows):
    return {'cases': len(rows), **{key: sum(r[key] for r in rows) for key in (
        'evidence_candidates', 'full_resolution_evidence_releases', 'candidate_violations',
        'cases_with_candidate_violation', 'overshooting_evidence_releases',
        'overshooting_visible_prefixes', 'cases_with_attained_overshoot',
        'generalized_evidence', 'justified_generalizations', 'excess_generalizations',
        'abstentions', 'case_with_changed_decision_vs_zero_shift', 'all_identifiers_retained',
        'all_task_fields_satisfied', 'task_fields_gained_vs_zero_shift',
        'task_fields_lost_vs_zero_shift',
    )}, 'max_attained_entropy_reduction_bits': max(r['max_attained_entropy_reduction_bits'] for r in rows)}


def sensitivity_row(result, matched, case, shift, budget, tol):
    timeline = result['decisions']
    curve = result['curve']
    assert [r['stage'] for r in curve] == list(range(len(timeline) + 1))
    assert len(timeline) == sum(m['phase'] == 'post' for m in case['messages'])
    evidence = []
    for step, (event, visible) in enumerate(zip(timeline, curve[1:], strict=True), start=1):
        attained = visible['entropy_drop_bits']
        candidate = event['true_candidate_bound_bits']
        released_exactly = event['decision'] == 'exact'
        candidate_violation = candidate is not None and released_exactly and candidate > budget + tol
        assert candidate_violation == event['over_budget_release']
        if event['component'] != 'neutral':
            assert candidate is not None
            if released_exactly:
                assert attained <= candidate + tol
                assert not (attained > budget + tol) or candidate_violation
            evidence.append({
                'post_delivery_step': step, 'role': event['role'], 'decision': event['decision'],
                'true_candidate_bound_bits': candidate,
                'gate_candidate_bound_bits': event['gate_estimated_bound_bits'],
                'attained_prefix_bits': attained, 'abstained': event['abstained'],
                'candidate_violation': candidate_violation,
                'exact_release_with_attained_overshoot': released_exactly and attained > budget + tol,
                'justified_generalization': event['decision'] == 'coarse' and candidate > budget + tol,
                'excess_generalization': event['decision'] == 'coarse' and candidate <= budget + tol,
            })
    changed = [e['decision'] for e in timeline] != [e['decision'] for e in matched['decisions']]
    violated = sum(e['candidate_violation'] for e in evidence)
    overshot = sum(c['entropy_drop_bits'] > budget + tol for c in curve[1:])
    generalized = sum(e['decision'] == 'coarse' for e in evidence)
    assert generalized == sum(e['justified_generalization'] + e['excess_generalization'] for e in evidence)
    return {
        'id': case['id'], 'domain': case['domain'], 'family': case['family'],
        'history': case['history'], 'budget_bits': budget, 'shift': shift,
        'rho': case['strength'] if case['family'] == 'soft' else None,
        'rho_hat': round(case['strength'] + shift, 2) if case['family'] == 'soft' else None,
        'evidence_candidates': len(evidence),
        'full_resolution_evidence_releases': sum(e['decision'] == 'exact' for e in evidence),
        'candidate_violations': violated, 'cases_with_candidate_violation': bool(violated),
        'overshooting_evidence_releases': sum(e['exact_release_with_attained_overshoot'] for e in evidence),
        'overshooting_visible_prefixes': overshot, 'cases_with_attained_overshoot': bool(overshot),
        'generalized_evidence': generalized, 'abstentions': sum(e['abstained'] for e in evidence),
        'justified_generalizations': sum(e['justified_generalization'] for e in evidence),
        'excess_generalizations': sum(e['excess_generalization'] for e in evidence),
        'case_with_changed_decision_vs_zero_shift': changed,
        'all_identifiers_retained': result['code_task_completed'],
        'all_task_fields_satisfied': result['task_completed'],
        'task_fields_gained_vs_zero_shift': result['task_completed'] and not matched['task_completed'],
        'task_fields_lost_vs_zero_shift': matched['task_completed'] and not result['task_completed'],
        'max_attained_entropy_reduction_bits': result['max_prefix_entropy_drop_bits'],
        'evidence_events': evidence,
        'visible_prefix_entropy_reduction_bits': [c['entropy_drop_bits'] for c in curve],
    }


def check_zero_shift(replay, archive):
    for actual, recorded in zip(replay['decisions'], archive['decisions'], strict=True):
        fields = ('role', 'phase', 'component', 'decision', 'released_text', 'true_candidate_bound_bits',
                  'gate_estimated_bound_bits', 'abstained', 'over_budget_release')
        for key in fields:
            assert (actual[key] == recorded[key] or
                    (isinstance(actual[key], float) and isinstance(recorded[key], float)
                     and abs(actual[key] - recorded[key]) < 1e-9)), (replay['id'], key)
    assert replay['curve'] == archive['curve']
    assert replay['task_completed'] == archive['task_completed']
    assert replay['code_task_completed'] == archive['code_task_completed']


def run(artifact):
    sys.path.insert(0, str(artifact / '复算脚本'))
    from corpus import make_cases
    from estimator import fit
    from replay import STRATEGIES, TOLERANCE, evaluate, evaluation_rows, source_messages

    hashes = verify_inputs(artifact)
    cases = load(artifact / '正式200题种子.json')
    training = make_cases(180, 12031, 'calibration')
    calibration = make_cases(80, 46733, 'calibration')
    model = fit(evaluation_rows(training), evaluation_rows(calibration))
    archived_rows = load(artifact / '自然语言实验结果.json')['rows']
    stored_records = (artifact / '独立Luna会话.jsonl').read_text(encoding='utf-8').splitlines()
    generated = {r['id']: r for r in map(json.loads, filter(None, stored_records))}
    assert len(cases) == len(stored_records) == len(generated) == 200
    assert {c['id'] for c in cases} == set(generated)
    assert Counter(c['family'] for c in cases)['soft'] == 66

    archive = {(r['strategy'], r['id']): r for r in archived_rows}
    assert len(archive) == len(archived_rows) == len(POLICY_NAMES) * len(cases)
    assert {r['strategy'] for r in archived_rows} == set(POLICY_NAMES) == set(STRATEGIES)
    assert all(r['input_origin'] == 'luna' for r in archived_rows)
    balanced = {policy: confusion([archive[policy, c['id']] for c in cases]) for policy in POLICY_NAMES}
    for c in cases:
        assert all(archive[k, c['id']]['truth'] == c['secret'] for k in POLICY_NAMES)
        phases = [m['phase'] for m in c['messages']]
        assert phases == sorted(phases, key=('pre', 'post').index)

    messages_by_id = {c['id']: source_messages(c, generated) for c in cases}
    rows, summaries = [], []
    for suffix, budget in BUDGETS:
        strategy = f'robust_{suffix}'
        zero_rows = {}
        for c in cases:
            origin, messages = messages_by_id[c['id']]
            result = evaluate(c, model, origin, messages, strategy, STRATEGIES[strategy])
            check_zero_shift(result, archive[strategy, c['id']])
            zero_rows[c['id']] = result
        for shift in OFFSETS:
            batch = []
            for c in cases:
                reference = zero_rows[c['id']]
                if c['family'] == 'soft' and shift != 0:
                    origin, messages = messages_by_id[c['id']]
                    gate_view = GatewayReliability(model, round(c['strength'] + shift, 2))
                    result = evaluate(c, gate_view, origin, messages, strategy, STRATEGIES[strategy])
                else:
                    result = reference
                batch.append(sensitivity_row(result, reference, c, shift, budget, TOLERANCE))
            assert len(batch) == len({row['id'] for row in batch}) == 200
            assert all(row['all_identifiers_retained'] for row in batch)
            rows.extend(batch)
            soft_rows = [r for r in batch if r['family'] == 'soft']
            assert len(soft_rows) == 66
            summaries.append({'budget_bits': budget, 'shift': shift,
                              'full_cohort': summarize(batch), 'soft_cases': summarize(soft_rows)})
    return {
        'input_hashes': hashes, 'archived_replay_sha256': sha256((artifact / '自然语言实验结果.json').read_bytes()).hexdigest(),
        'case_truth_counts': dict(Counter(c['secret'] for c in cases)),
        'balanced_accuracy': balanced, 'reliability_conditions': summaries,
        'soft_cases_and_chronology': {'soft_cases': 66, 'soft_evidence_candidates': summaries[0]['soft_cases']['evidence_candidates'],
                                      'scope': 'Only the online estimator saw perturbed vote reliability. The original truth, transcript, order, and exact oracle were held fixed.',
                                      'zero_shift_validation': 'All decisions, release texts, cumulative curves, and task outcomes match the archived replay for both budgets.'},
        'paired_case_results': rows,
    }


def manuscript(results):
    lines = [
        '### Class-Balanced Reconstruction Accuracy', '',
        'The frozen cases contain 110 realized class-0 secrets and 90 class-1 secrets. Table S1 reports case-level maximum-a-posteriori predictions with the registered tie-to-zero rule. We define balanced accuracy as the mean of the two class-specific recalls. Fixed field generalization and integrity-aware zero-bit gating both attain a raw accuracy of 55.0% and balanced accuracy of 50.0%, consistent with an uninformative posterior under the model.', '',
        '**TABLE S1. MAP confusion counts on the 200 frozen Luna cases**', '',
        '| Policy | True 0, predicted 0 | True 0, predicted 1 | True 1, predicted 0 | True 1, predicted 1 | Accuracy | Balanced accuracy |',
        '|---|---:|---:|---:|---:|---:|---:|',
    ]
    for key, row in results['balanced_accuracy'].items():
        cells = [POLICY_NAMES[key], *(str(row[n]) for n in ('n00', 'n01', 'n10', 'n11')),
                 f'{row["accuracy"]:.1%}', f'{row["balanced_accuracy"]:.1%}']
        lines.append('| ' + ' | '.join(cells) + ' |')
    lines.extend([
        '', '### Sensitivity to Soft-Evidence Reliability', '',
        'We vary the reliability supplied to the online estimator by −0.10, −0.05, 0, +0.05, and +0.10 while retaining the original simulated observations, delivery order, and exact scoring reliability. The 66 soft cases in the frozen 200-case cohort supply the affected evidence candidates. Both zero-shift replays reproduce the archived decisions and observed entropy curves. Table S2 distinguishes releases whose exact candidate envelope exceeds the budget from cases where a visible prefix actually exceeds it. An envelope can be violated even when the candidate that actually arrives produces less information than the worst alternative.', '',
        '**TABLE S2. Integrity-aware gate when assumed reliability is shifted**', '',
        '| Budget (bit) | Reliability shift | Soft exact releases | Above-budget envelope releases | Exact releases with attained prefix above budget | Cases with attained overshoot (out of 66) | Soft generalized candidates, justified/excess | All fields satisfied (out of 200) |',
        '|---:|---:|---:|---:|---:|---:|---:|---:|',
    ])
    for item in results['reliability_conditions']:
        soft = item['soft_cases']
        full = item['full_cohort']
        shift = f'{item["shift"]:+.2f}' if item['shift'] else '0.00'
        cells = [f'{item["budget_bits"]:.2f}', shift,
                 str(soft['full_resolution_evidence_releases']), str(soft['candidate_violations']),
                 str(soft['overshooting_evidence_releases']), str(soft['cases_with_attained_overshoot']),
                 f'{soft["justified_generalizations"]}/{soft["excess_generalizations"]}',
                 str(full['all_task_fields_satisfied'])]
        lines.append('| ' + ' | '.join(cells) + ' |')
    n = results['soft_cases_and_chronology']['soft_evidence_candidates']
    lines.extend([
        '', f'Each condition contains {n} soft-evidence candidates. A justified generalization suppresses a candidate whose exact envelope exceeds the budget at that prefix. An excess generalization suppresses one whose exact envelope would have fit. The replay retains every required identifier in all 200 cases per condition. Deterministic cases remain paired controls.', '',
    ])
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--artifact', type=Path, default=ROOT / 'outputs' / '撤权拼图四项升级实验')
    parser.add_argument('--out', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    result = run(args.artifact.resolve())
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / 'results.json').write_text(json.dumps(result, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8')
    (args.out / 'quant.md').write_text(manuscript(result), encoding='utf-8')
    for condition in result['reliability_conditions']:
        print(condition['budget_bits'], condition['shift'], condition['soft_cases']['candidate_violations'],
              condition['soft_cases']['cases_with_attained_overshoot'], condition['full_cohort']['all_task_fields_satisfied'])


if __name__ == '__main__':
    main()
