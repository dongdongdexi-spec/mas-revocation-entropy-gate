### Class-Balanced Reconstruction Accuracy

The frozen cases contain 110 realized class-0 secrets and 90 class-1 secrets. Table S1 reports case-level maximum-a-posteriori predictions with the registered tie-to-zero rule. We define balanced accuracy as the mean of the two class-specific recalls. Fixed field generalization and integrity-aware zero-bit gating both attain a raw accuracy of 55.0% and balanced accuracy of 50.0%, consistent with an uninformative posterior under the model.

**TABLE S1. MAP confusion counts on the 200 frozen Luna cases**

| Policy | True 0, predicted 0 | True 0, predicted 1 | True 1, predicted 0 | True 1, predicted 1 | Accuracy | Balanced accuracy |
|---|---:|---:|---:|---:|---:|---:|
| Explicit labels | 110 | 0 | 28 | 62 | 86.0% | 84.4% |
| Uniform generalization | 110 | 0 | 90 | 0 | 55.0% | 50.0% |
| Fixed field generalization | 110 | 0 | 90 | 0 | 55.0% | 50.0% |
| Per-message estimation | 110 | 0 | 57 | 33 | 71.5% | 68.3% |
| Exact reference, 0 bit | 110 | 0 | 90 | 0 | 55.0% | 50.0% |
| Local-history shared, 0 bit | 110 | 0 | 70 | 20 | 65.0% | 61.1% |
| Local-history shared, 0.25 bit | 110 | 0 | 70 | 20 | 65.0% | 61.1% |
| Local-history shared, 0.5 bit | 102 | 8 | 40 | 50 | 76.0% | 74.1% |
| Local-history shared, 1 bit | 110 | 0 | 28 | 62 | 86.0% | 84.4% |
| Local-history shared, unlimited | 110 | 0 | 28 | 62 | 86.0% | 84.4% |
| Integrity-aware shared, 0 bit | 110 | 0 | 90 | 0 | 55.0% | 50.0% |
| Integrity-aware shared, 0.25 bit | 110 | 0 | 90 | 0 | 55.0% | 50.0% |
| Integrity-aware shared, 0.5 bit | 102 | 8 | 60 | 30 | 66.0% | 63.0% |
| Integrity-aware shared, 1 bit | 110 | 0 | 28 | 62 | 86.0% | 84.4% |
| Integrity-aware shared, unlimited | 110 | 0 | 28 | 62 | 86.0% | 84.4% |

### Sensitivity to Soft-Evidence Reliability

We vary the reliability supplied to the online estimator by −0.10, −0.05, 0, +0.05, and +0.10 while retaining the original simulated observations, delivery order, and exact scoring reliability. The 66 soft cases in the frozen 200-case cohort supply the affected evidence candidates. Both zero-shift replays reproduce the archived decisions and observed entropy curves. Table S2 distinguishes releases whose exact candidate envelope exceeds the budget from cases where a visible prefix actually exceeds it. An envelope can be violated even when the candidate that actually arrives produces less information than the worst alternative.

**TABLE S2. Integrity-aware gate when assumed reliability is shifted**

| Budget (bit) | Reliability shift | Soft exact releases | Above-budget envelope releases | Exact releases with attained prefix above budget | Cases with attained overshoot (out of 66) | Soft generalized candidates, justified/excess | All fields satisfied (out of 200) |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 0.25 | -0.10 | 66 | 66 | 66 | 66 | 167/0 | 156 |
| 0.25 | -0.05 | 23 | 23 | 23 | 23 | 210/0 | 133 |
| 0.25 | 0.00 | 0 | 0 | 0 | 0 | 233/0 | 122 |
| 0.25 | +0.05 | 0 | 0 | 0 | 0 | 233/0 | 122 |
| 0.25 | +0.10 | 0 | 0 | 0 | 0 | 233/0 | 122 |
| 0.50 | -0.10 | 104 | 28 | 16 | 16 | 129/0 | 156 |
| 0.50 | -0.05 | 66 | 0 | 0 | 0 | 167/0 | 156 |
| 0.50 | 0.00 | 66 | 0 | 0 | 0 | 167/0 | 156 |
| 0.50 | +0.05 | 23 | 0 | 0 | 0 | 58/152 | 133 |
| 0.50 | +0.10 | 0 | 0 | 0 | 0 | 0/233 | 122 |

Each condition contains 233 soft-evidence candidates. A justified generalization suppresses a candidate whose exact envelope exceeds the budget at that prefix. An excess generalization suppresses one whose exact envelope would have fit. The replay retains every required identifier in all 200 cases per condition. Deterministic cases remain paired controls.
